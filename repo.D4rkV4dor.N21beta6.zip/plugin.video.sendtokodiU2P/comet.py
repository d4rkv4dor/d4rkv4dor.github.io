import requests
from urllib.parse import urlparse, parse_qs, unquote, quote
import re
try:
    from util import notice
except: pass
#import cloudscraper

class Comet:

    def __init__(self, urlBase):
        self.urlBase = urlBase

    def extractResoName(self, name, taille):
        reso = {"2160": False, "4K": False, "1080": False, "720": False, "480": False, "360": False, "3D": False, "XVID": False}
        typeReso = {"ULTRAHDLIGHT": False, "4KLIGHT": False, "FULLHD": False, "HDLIGHT": False, "LIGHT": False, "REMUX": False}
        source = {"BLURAY": False, "WEBRIP": False, "WEB": False, "BDRIP": False, "BRRIP": False, "DVDRIP": False, "HDTV": False, "HDRIP": False, "CAM": False}
        audio = {"VOSTFR": False, "TRUEFRENCH": False, "FRENCH": False, "VF": False, "VFF": False, "VFI": False, "VFQ": False, "VO": False, "MULTI": False}
        extension = {"avi": False, "divx": False, "mkv": False, "mp4": False, "ts": False, "mpg": False}

        release = unquote(name)

        # Normalisation scène
        clean = re.sub(r'[\s_\-\[\]\(\)]+', '.', name.upper())


        # Regex audio (FRENCH sans SUBFRENCH)
        audio_regex = {
            "VOSTFR": r'(?:\.|^)(VOST(FR)?)(?:\.|$)',
            "TRUEFRENCH": r'(?:\.|^)(TRUEFRENCH)(?:\.|$)',
            "FRENCH": r'(?<!SUB)(?<!SUB\.)(?<!SUB-)(?<!SUB_)(?:\.|^)(FRENCH)(?:\.|$)',
            "VF": r'(?:\.|^)(VF|VFF|VFI|VFQ)(?:\.|$)',
            "VO": r'(?:\.|^)(VO)(?:\.|$)',
            "MULTI": r'(?:\.|^)(MULTI)(?:\.|$)',
        }

        for key, rgx in audio_regex.items():
            if re.search(rgx, release, re.I):
                audio[key] = True

        # Détection reso / source / type
        for table in (reso, typeReso, source):
            for key in table:
                if re.search(rf'(?:\.|^){key}P?(?:\.|$)', release, re.I):
                    table[key] = True

        resof = "-".join([k for k, v in reso.items() if v])
        if not resof:
            resof = "SD"
        typeResof =  "-".join([k for k, v in typeReso.items() if v])
        audiof = "-".join([k for k, v in audio.items() if v])
        sourcef = "-".join([k for k, v in source.items() if v])

        return  resof + ("-%s" %typeResof if typeResof else "") + ("-%s" %audiof if audiof else "") + ("-%s" %sourcef if sourcef else "") + " (%s)" %taille

    def extract_size(self, text):
        pattern = r'(\d+(?:\.\d+)?)\s*(KB|MB|GB|TB)'
        match = re.search(pattern, text, re.IGNORECASE)

        if match:
            value = match.group(1)
            unit = match.group(2).upper()
            return value + unit
        return None

    def remove_emojis(self, text):
        emoji_pattern = re.compile(
            "["
            "\U0001F600-\U0001F64F"  # emoticons
            "\U0001F300-\U0001F5FF"  # symbols & pictographs
            "\U0001F680-\U0001F6FF"  # transport & map
            "\U0001F1E0-\U0001F1FF"  # flags
            "\U00002700-\U000027BF"  # dingbats
            "\U000024C2-\U0001F251"
            "]+", flags=re.UNICODE
        )
        return emoji_pattern.sub("", text).replace("\r", "").replace("\n", "")

    def getMovie(self, idImdb):
        url = self.urlBase + "/stream/movie/%s.json" %idImdb
        resp = requests.get(url)
        resp = resp.json()
        #print(str(resp).encode("utf-8"))
        links = self.resolve_streams(resp)
        return links

    def getSerie(self, idImdb, saison, episode):
        #tt27497448%3A1%3A1.json
        url = self.urlBase + "/stream/series/" + quote("%s:%s:%s" %(idImdb, saison, episode)) + ".json"
        #notice(url)
        resp = requests.get(url)
        resp = resp.json()
        #print(resp)
        links = self.resolve_streams(resp)
        return links

    def resolve_streams(self, json_data):
        result = {}
        for stream in json_data.get("streams", []):
            url = stream.get("infoHash", "")
            if url:
                name = stream.get("description", "")
                name = self.remove_emojis(name)
                if not url:
                    continue
                links = [url]
                if url:
                    if name in result:
                        result[name].extend(links)
                    else:
                        result[name] = links

        # Supprimer doublons
        for f in result:
            result[f] = sorted(set(result[f]))

        return result




if __name__ == "__main__":
    sf = Comet("https://comet.feels.legal/eyJtYXhSZXN1bHRzUGVyUmVzb2x1dGlvbiI6NSwibWF4U2l6ZSI6MCwiY2FjaGVkT25seSI6ZmFsc2UsInNvcnRDYWNoZWRVbmNhY2hlZFRvZ2V0aGVyIjpmYWxzZSwicmVtb3ZlVHJhc2giOnRydWUsInJlc3VsdEZvcm1hdCI6WyJhbGwiXSwiZGVicmlkU2VydmljZXMiOlt7InNlcnZpY2UiOiJhbGxkZWJyaWQiLCJhcGlLZXkiOiI2UDY5TWxOVUxNQ1VKTWVoTGdnZyJ9XSwiZW5hYmxlVG9ycmVudCI6dHJ1ZSwiZGVkdXBsaWNhdGVTdHJlYW1zIjpmYWxzZSwic2NyYXBlRGVicmlkQWNjb3VudFRvcnJlbnRzIjpmYWxzZSwiZGVicmlkU3RyZWFtUHJveHlQYXNzd29yZCI6IiIsImxhbmd1YWdlcyI6eyJyZXF1aXJlZCI6WyJtdWx0aSIsImVuIiwiZnIiXSwiYWxsb3dlZCI6W10sImV4Y2x1ZGUiOltdLCJwcmVmZXJyZWQiOlsibXVsdGkiLCJmciJdfSwicmVzb2x1dGlvbnMiOnt9LCJvcHRpb25zIjp7InJlbW92ZV9yYW5rc191bmRlciI6LTEwMDAwMDAwMDAwLCJhbGxvd19lbmdsaXNoX2luX2xhbmd1YWdlcyI6ZmFsc2UsInJlbW92ZV91bmtub3duX2xhbmd1YWdlcyI6ZmFsc2V9fQ==")
    links = sf.getMovie("tt10374610")
    print(str(links).encode("utf-8"), len(links))
