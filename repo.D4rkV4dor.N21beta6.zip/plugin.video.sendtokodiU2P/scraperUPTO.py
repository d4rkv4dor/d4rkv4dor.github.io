# -*- coding: utf-8 -*-
import json
import os
import sys
import requests
import io
import unicodedata
import re
import ast
import sqlite3
import shutil
import time
import threading
import widget
from urllib.parse import unquote, urlencode, quote
from html.parser import HTMLParser
import urllib.request
pyVersion = sys.version_info.major
pyVersionM = sys.version_info.minor
import cryptPaste2 as cryptage

import zipfile
#import cryptPaste as cryptage
try:
    HANDLE = int(sys.argv[1])
except:
    HANDLE = 1
try:
    import xbmc
    import xbmcvfs
    import xbmcaddon
    import xbmcgui
    import xbmcplugin
    ADDON = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
    KEYTMDB = ADDON.getSetting("apikey")
    BDREPO = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/mymedia.db')
    CHEMIN = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P')
    BDBOOKMARK = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/bookmark.db')
    NBMEDIA = int(ADDON.getSetting("nbupto"))
    KEYUPTO = ADDON.getSetting("keyUpto")
    KEYALL = ADDON.getSetting("keyalldebrid")
    KEYREAL = ADDON.getSetting("keyrealdebrid")
    EXTUPTO = ADDON.getSetting("extupto")
except:
    KEYTMDB = "96139384ce46fd4ffac13e1ad770db7a"

try:
    from util import *
except:
    def notice(content):
        log(content, xbmc.LOGINFO)

    def log(msg, level=xbmc.LOGINFO):
        addon = xbmcaddon.Addon()
        addonID = addon.getAddonInfo('id')
        xbmc.log('%s: %s' % (addonID, msg), level)
    def showInfoNotification(message):
        xbmcgui.Dialog().notification("U2Pplay", message, xbmcgui.NOTIFICATION_INFO, 5000)

    def showErrorNotification(message):
        xbmcgui.Dialog().notification("U2Pplay", message,
                                  xbmcgui.NOTIFICATION_ERROR, 5000)

class PopupWindow(xbmcgui.WindowDialog):
    def __init__(self, image, line1, line2, line3, line4, line5):
        self.addControl(xbmcgui.ControlImage(x=25, y=25, width=1000, height=100, filename=xbmcvfs.translatePath('special://home/addons/plugin.video.sendtokodiU2P/back.png')))
        self.addControl(xbmcgui.ControlImage(x=25, y=25, width=100, height=100, filename=image))
        self.addControl(xbmcgui.ControlLabel(x=190, y=25, width=500, height=25, label=line1))
        self.addControl(xbmcgui.ControlLabel(x=190, y=50, width=500, height=25, label=line2))
        self.addControl(xbmcgui.ControlLabel(x=190, y=75, width=500, height=25, label=line3))
        self.addControl(xbmcgui.ControlLabel(x=190, y=100, width=500, height=25, label=line4))
        self.addControl(xbmcgui.ControlLabel(x=190, y=125, width=500, height=25, label=line5))

class PopupWindowNew(xbmcgui.WindowDialog):
    def __init__(self, image, films=[], series=[]):
        ajoutSerie = max([0, 7 - len(films)])
        ajoutFilm = max([0, 7 - len(series)])
        l = 70
        lc = 100
        if series:
            lc += 55
        if films:
            lc += 55
        lc += min(14, len(films) + len(series)) * (l + 5)
        self.addControl(xbmcgui.ControlImage(x=20, y=15, width=lc, height=100, filename=xbmcvfs.translatePath('special://home/addons/plugin.video.sendtokodiU2P/back.png')))
        self.addControl(xbmcgui.ControlImage(x=20, y=15, width=100, height=100, filename=image))
        x = 125
        if films:
            self.addControl(xbmcgui.ControlLabel(x=125, y=20, width=100, height=80, label="News\nFilms"))
            x = 180
            for i, img in enumerate(films[: 7 + ajoutSerie]):
                if img:
                    image2 = "http://image.tmdb.org/t/p/w185" + img
                else:
                    image2 = ""
                pos = (x + (i * l) + (5 * i))
                self.addControl(xbmcgui.ControlImage(x=pos, y=15, width=l, height=100, filename=image2))
            pos += (l + 5)
        else:
            pos = x
        if series:
            self.addControl(xbmcgui.ControlLabel(x=pos, y=20, width=100, height=80, label="News\nSeries"))
            x = pos + 55
            for i, img in enumerate(series[: 7 + ajoutSerie]):
                image2 = "http://image.tmdb.org/t/p/w185" + img
                pos = (x + (i * l) + (5 * i))
                self.addControl(xbmcgui.ControlImage(x=pos, y=15, width=l, height=100, filename=image2))


class UptoLocal:

    def __init__(self):
        self.page = 1
        self.tabMedia = []
        self.tabPages = []

    def testThread(self, nom):
        a = 0
        tActif = True
        while tActif:
            tActif = False
            for t in threading.enumerate():
                if nom == t.getName():
                    tActif = True
            time.sleep(0.1)
            a += 1
            if a > 150:
                break
        return True

    def getFile(self, folder, hsh, i=100, j=0):
        """extract info folder upto publique"""
        tabMedia = []
        a = 0
        while 1:
            try:
                url = "https://{}/api/user/public?folder={}&hash={}&limit={}&offset={}".format(EXTUPTO, folder, hsh, i, j)
                r = requests.get(url)
                data = r.json()
                if data['data']["list"]:
                    for d in data['data']["list"]:
                        if 'file_created' in d.keys():
                            dd = (d['file_created'], d['file_name'], d['file_code'])
                        else:
                            dd = (d['file_date_inserted'], d['file_name'], d['file_code'])
                        tabMedia.append(dd)
                    j += i
                else:
                    break
            except Exception as e:
                #notice(str(e))
                notice("err get file %d" %a)
                if a > 3:
                    break
                else:
                    time.sleep(0.15 * a)
                    a += 1
        return tabMedia


    def getFilePublic(self, i, j, folderNum, hashNum):
        url = "https://{}/api/user/public?folder={}&hash={}&limit={}&offset={}".format(EXTUPTO, folderNum, hashNum, j, i)
        r = requests.get(url)
        data = r.json()
        #notice(data)
        try:
            if data['data']["list"]:
                [self.tabMedia.append((d['file_date_inserted'], d['file_name'], d['file_code'])) for d in data['data']["list"]]
            return [(d['file_date_inserted'], d['file_name'], d['file_code']) for d in data['data']["list"]], data['data']["pageCount"]
        except:
            return [], 0

    def getFileSeries(self, i, folderNum, hashNum):
        url = "https://{}/api/user/public?folder={}&hash={}&limit=100&offset={}".format(EXTUPTO, folderNum, hashNum, i)
        r = requests.get(url)
        try:
            data = r.json()
            nbPage = data['data']['pageCount']
            if data['data']["list"]:
                for d in data['data']["list"]:
                    if 'file_created' in d.keys():
                        dd = (d['file_created'], d['file_name'], d['file_code'])
                    else:
                        dd = (d['file_date_inserted'], d['file_name'], d['file_code'])
                self.tabMedia.append(dd)
                #[self.tabMedia.append((d['file_created'], d['file_name'], d['file_code'])) for d in data['data']["list"]]
            return [(d['file_name'], d['file_code']) for d in data['data']["list"]], (nbPage, folderNum, hashNum)
        except:
            notice("err " + folderNum + " " + hashNum)
            return [], []

    def getFileFolderPublicAll(self, folderNum="", hashNum=""):
        """extract info folder upto publique"""
        i, j = 100, 0
        url = "https://{}/api/user/public?folder={}&hash={}&limit={}&offset={}".format(EXTUPTO, folderNum, hashNum, i, j)
        r = requests.get(url)
        data = r.json()

        if data['statusCode'] == 0 and data['data']["list"]:
            #[self.tabMedia.append((d['file_created'], d['file_name'], d['file_code'])) for d in data['data']["list"]]
            for d in data['data']["list"]:
                if 'file_created' in d.keys():
                    dd = (d['file_created'], d['file_name'], d['file_code'])
                else:
                    dd = (d['file_date_inserted'], d['file_name'], d['file_code'])
                self.tabMedia.append(dd)
            j += i
        else:
            return []
        self.page = data['data']['pageCount']
        #notice("nb page %d %s" %(self.page, folderNum))
        a = 2
        while self.page >= a:
            try:
                threading.Thread(name=folderNum, target=self.getFilePublic, args=(j, i, folderNum, hashNum,)).start()
                j += i
                time.sleep(0.05)
                a += 1

            except Exception as e:
                notice(e)
        self.testThread(folderNum)
        return [(x[1], x[2]) for x in self.tabMedia[::-1]]


    def extractResoName(self, name):
        reso = {"1080": False, "720": False, "2160": False, "480": False, "4K": False, '360': False, "3D": False, "xvid":False}
        typeReso = {"HDlight": False, "Light": False, "ultraHDlight": False, "fullhd": False, "REMUX": False, "4KLight": False}
        source = {"BLURAY": False, "WEB": False, "WEBRIP": False, "DVDRiP": False, "BDRIP": False, "HDTV": False, "BRRip": False, "HDrip": False, "Cam": False, "IMAX": False, \
            "SDR": False, "HDR": False, "Dolby.vision": False, "10bits": False}
        audio = {"VO": False, "VOSTFR": False, "VFF": False, "VFI": False, 'VFQ': False, "VF": False, "FR.JP": False, "FR.EN": False, "VOA": False, "TRUEFRENCH": False, "French": False, "Multi": False, "VOF": False,\
            "DD5.1": False, "DTS-HD.MA.TrueHD.5.1": False, "AC3.5.1": False, "DoVi": False, "DDP5.1": False, "DDP7.1": False}
        extension = {"avi": False, "divx": False, "mkv": False, "mp4": False, "ts": False, "mpg": False}
        name = unquote(name)
        #print(name)
        for m in ["_", " ", "[", "]", "-", "(", ")"]:
            name = name.replace(m, ".")
        masque = r'(.*)([\.\(]19\d\d|[\.\(]20\d\d)(?P<release>[\.\)].*)'
        r = re.match(masque, name)
        try:
            release = r.group("release")
        except:
            release = name
            #print("erreur reso name:", name)
        for tab in [reso, typeReso, audio, source]:
            for motif in tab.keys():
                r = re.search(r'(\.)(%s)p?\.' %motif, release, re.I)
                if r:
                    tab[motif] = True
        for ext in extension.keys():
            if ext == release[-3:]:
                extension[ext] = True

        return [name, [k for k, v in reso.items() if v], [k for k, v in typeReso.items() if v], [k for k, v in audio.items() if v], [k for k, v in extension.items() if v], [k for k, v in source.items() if v]]

    def reso(self, name):
        argv = self.extractResoName(name)
        ext = argv.pop(-2)
        if not argv[4]:
            if "avi" in ext:
                argv[4] = ['480']
        resoRelease = "%s" %".".join(["-".join(x) for x in argv[1:] if x])
        return resoRelease


class TMDB:
    def __init__(self, key):
      self.key = key
      self.urlBase = "https://api.themoviedb.org/3/"
      self.lang = "fr"
      self.tabMedia = []
      self.tabMediaFinal = []


    def movieNumId(self, numId, filecode, pos, release="", repo=""):
        """infos films suivant numID"""
        #&append_to_response=images
        url1 = self.urlBase  + "movie/{}?api_key={}&language=fr".format(numId, self.key)
        req = requests.request("GET", url1, data=None)
        dictInfos = req.json()
        try:
          saga = dictInfos.get("belongs_to_collection", {}).get("id", 0)
        except:
          saga = 0
        title = dictInfos.get("title", "")
        poster = dictInfos.get("poster_path", "")
        backdrop = dictInfos.get("backdrop_path", "")
        try:
            genres = ", ".join([z for y in dictInfos["genres"] for x, z in y.items() if x =="name"])
        except:
            genres = ""
        year = dictInfos.get("release_date", '2010')[:4]
        overview = dictInfos.get("overview", "sans synopsis.....")
        popu = dictInfos.get("vote_average", 0.0)
        lang = dictInfos.get("original_language", "")
        votes = dictInfos.get("vote_count", 0)
        dateRelease = dictInfos.get("release_date", "2010-06-10")
        runTime = dictInfos.get("runtime", 0)
        try:
            logo = dictInfos["images"]["logos"][0]["file_path"]
        except:
            logo = ""
        self.tabMedia.append((pos, release, numId, title, year, genres, filecode, repo))
        return numId, title, overview, poster, year, genres, backdrop, popu, votes, dateRelease, runTime, lang, logo, saga


    def searchMovie(self, title, filecode, pos, year=0, release="", repCrypt=0, repo=""):
        """search film par nom et annee"""
        self.title = title
        sauveTitle = title
        self.sauveTitle = sauveTitle
        self.year = year
        title = title.replace(".", " ")
        title = title.replace(" ", "+")
        #title = unicodedata.normalize('NFD', title).encode('ascii','ignore').decode("utf-8")
        title = quote(title)
        dictMovies = {}
        if int(year) > 0:
            Url = "search/movie?query={}&api_key={}&page=1&language={}&year={}".format(title, self.key, self.lang, year)
            Url = "search/movie?query={}&api_key={}&page=1&language={}&primary_release_year={}".format(title, self.key, self.lang, year)
        else:
            Url = "search/movie?query={}&api_key={}&page=1&language={}".format(title, self.key, self.lang)
        try:
            req = requests.get(self.urlBase + Url)
            dictMovies = req.json()
            if year > 0 and dictMovies["total_results"] == 0:
                Url = "search/movie?query={}&api_key={}&page=1&language={}".format(title, self.key, self.lang)
                req = requests.get(self.urlBase + Url)

                dictMovies = req.json()
        except Exception as e:
            pass
        try:
          genres = dictMovies["results"][0]["genre_ids"]
          dictMovies["results"][0]["genre_ids"] = self.formatGenre(genres)
        except: pass
        if "results" not in dictMovies.keys()  or not dictMovies["results"]:
            dictMovies = {u'total_results': 1, u'total_pages': 1, u'page': 1, u'results': [{u'poster_path': u'', u'title': unquote(sauveTitle), u'overview': u'', u'release_date': year, u'popularity': 0,\
             u'original_title': u'', u'backdrop_path': u'', u'vote_count': 0, u'video': False, u'adult': False, u'vote_average': 0, u'genre_ids': [], u'id': 0, u'original_language': u''}]}

        if release:
            dictMovies["results"][0]["overview"] = "Release: %s\n" %release + dictMovies["results"][0]["overview"]


        if repCrypt:
            #numId, title, year, genre
            if dictMovies["results"][0]["id"]:
                try:
                    dictMovies["results"][0]["release_date"] = dictMovies["results"][0]["release_date"][:4]
                except:
                    dictMovies["results"][0]["release_date"] = "0"
                tabInfo = (pos, release, dictMovies["results"][0]["id"], dictMovies["results"][0]["title"], dictMovies["results"][0]["release_date"],\
                    dictMovies["results"][0]["genre_ids"], filecode, repo)
            else:
                tabInfo = (pos, release, release, 0, 0, 0, filecode, repo)

        else:
            if dictMovies["results"][0]["id"]:
                tabInfo = (pos, release + " TM%dTM" %dictMovies["results"][0]["id"], dictMovies["results"][0]["title"], dictMovies["results"][0]["id"], 0, 0, filecode, "film")
            else:
                tabInfo = (pos, release, "", 0, 0, 0, filecode, "divers")

        self.tabMedia.append(tabInfo)

        return dictMovies

    def formatGenre(self, tab):
      dictGenre={28:"Action", 12:"Aventure", 16:"Animation", 35:"Comedie", 80:"Crime", 99:"Documentaire", 18:"Drame", 10751:"Familial", 14:"Fantastique", 10769:"Etranger", 36:"Histoire", 27:"Horreur",
                  10402:"Musique", 9648:"Mystere", 10749:"Romance", 878:"Science-Fiction", 10770:"Telefilm", 53:"Thriller", 10752:"Guerre", 37:"Western",
                  10759:"Action & Adventure", 10762:"Kids", 9648:"Mystery", 10763:"News", 10764:"Reality", 10765:"Science-Fiction & Fantastique", 10766:"Soap", 10767:"Talk", 10768:"War & Politics",
                  28:"Action", 12:"Aventure",10751:"Familial"}
      return ", ".join([dictGenre[x] for x in tab])

    def searchEpisode(self, nom, saison, episode, filecode, pos, year=0, release=""):
        """rechercher serie par nom"""
        sauveTitle = "{} ({}".format(nom, episode)
        self.sauveTitle = sauveTitle
        self.year = year
        tabRemp = [("(", " "), (")", " "), (".", " "), ("2020", ""), ("2019", ""), ("2021", ""), ("2022", "")]
        for remp in tabRemp:
            nom = nom.replace(remp[0], remp[1])
        nom = nom.strip()
        nom = nom .replace(" ", "+")
        if int(year) > 0:
            url1 = self.urlBase + "search/tv?query={}&api_key={}&page=1&language={}&first_air_date_year={}".format(nom, self.key, self.lang, year)
        else:
            url1 = self.urlBase + "search/tv?query={}&api_key={}&page=1&language={}".format(nom, self.key, self.lang)
        dict_serie = {}
        try:
          req = requests.get(url1)
          dict_serie = req.json()
          try:
            dict_serie["results"][0]["genre_ids"] = self.formatGenre(dict_serie["results"][0]["genre_ids"])
          except: pass
          dict_serie["results"][0]["release_date"] = dict_serie["results"][0]['first_air_date']
          dict_serie["results"][0]["title"] = dict_serie["results"][0]['name']
        except Exception as e:
          pass
        if "results" not in dict_serie.keys() or not dict_serie["results"]:
            dict_serie = {u'total_results': 1, u'total_pages': 1, u'page': 1, u'results': [{u'poster_path': u'', u'title': unquote(sauveTitle), u'overview': u'', u'release_date': year, u'popularity': 0, u'original_title': u'', u'backdrop_path': u'',\
                     u'vote_count': 0, u'video': False, u'adult': False, u'vote_average': 0, u'genre_ids': [], u'id': 0, u'original_language': u''}]}

        if release:
          dict_serie["results"][0]["overview"] = "Release: %s\n" %release + dict_serie["results"][0]["overview"]

        if dict_serie["results"][0]["id"]:
            tabInfo = (pos, release + " TM%dTM" %dict_serie["results"][0]["id"], dict_serie["results"][0]["title"], dict_serie["results"][0]["id"], int(saison), int(episode.split("E")[1]), filecode, "serie")
        else:
            tabInfo = (pos, release, "", 0, 0, 0, filecode, "divers")
        self.tabMedia.append(tabInfo)
        return dict_serie

    def saison(self, numId, saison):
      url1 = self.urlBase + "tv/{}/season/{}?api_key={}&language={}".format(numId, saison, self.key, self.lang)
      req = requests.get(url1)
      dictInfos = req.json()
      tabEpisodes = []
      try:
        for i, episode in enumerate(dictInfos["episodes"]):
          name = episode.get("name", "")
          overview = episode.get("overview", "")
          if not overview:
            overview = "Pas de Synopsis...."
          dateRelease = episode.get("air_date", "")
          backdrop = episode.get("still_path", "")
          popu = episode.get("vote_average", 0.0)
          numSaison = episode.get("season_number", int(saison))
          numEpisode = episode.get("episode_number", 1 + i)
          tabEpisodes.append([name, overview, dateRelease, backdrop, popu, numSaison, numEpisode])
      except: pass
      return tabEpisodes


    @property
    def extractListe(self):
        return self.tabMedia

class RenameMedia:

    def extractInfo(self, name, typM="serie"):
        name = unquote(name)
        if typM == "movie":
            motif = r"""(?P<film>.*)([_\.\(\[ -]{1})(?P<an>19\d\d|20\d\d)([_\.\)\] -]{1})(.*)"""
            try:
                r = re.match(motif, name)
                title = r.group('film')
            except:
                title = name[:-4]
            try:
                year = int(r.group('an').replace('.', ''))
            except:
                year = 0
            if r:
                nameFinal = self.correctNom(title)
                nameFinal = nameFinal.replace(str(year), "")
            else:
                nameFinal = name

            return [nameFinal, year]

        else:
            for m in ["_", " ", "[", "]", "-", "(", ")", "{", "}", ",", ";"]:
                name = name.replace(m, ".")
            tab_remp = [r'''-|_|iNTERNAL|MULTi|2160p|4k|1080p|720p|480p|WEB-DL|hdlight|WEB|AC3|aac|hdtv|hevc|\d\dbit|subs?\.|vos?t?|x\.?265|STEGNER|x\.?264|FRENCH|DD\+.5.1|DD\+| |SR\.?71|h264|h265|1920x1080''', '.']
            name = re.sub(tab_remp[0], tab_remp[1], name, flags=re.I)
            name = re.sub(r"\.{2,}", ".", name)
            masque = r'(?P<year>19\d\d|20\d\d)'
            r = re.search(masque, name)
            if r:
                year = r.group("year")
            else:
                year = 0

            if year:
                name = name.replace(year, "")
            masques = [r'[sS](?P<saison>\d?\d)\.?(ep?)\.?(?P<episode>\d\d\d\d)\.',
                       r'[sS](?P<saison>\d?\d)\.?(ep?)\.?(?P<episode>\d?\d?\d)\.',
                       r'(?P<saison>\d?\d)\.?([xX])\.?(?P<episode>\d?\d?\d)\.',
                       r'(\.)(ep?)\.?(?P<episode>\d?\d?\d)\.',
                       r'(part)\.?(?P<episode>\d)\.',
                       r'(dvd)\.?(?P<episode>\d)\.',
                       r'(Saison)\.?(?P<saison>\d?\d)\.?(Episode|e)\.?(?P<episode>\d?\d)\.',
                       r'[sS](?P<saison>\d?\d)\.?(ep?)\.?(?P<episode>\d?\d?\d)',
                       r'(ep?)\.?(?P<episode>[0-1][0-8]\d\d)\.',
                       r'(ep?)\.?(?P<episode>\d?\d?\d)',
                       r'(?P<episode>[0-1][0-8]\d\d)',
                       r'(?P<episode>\d?\d?\d)',
                       ]

            for motif in masques:
                r = re.search(motif, name, re.I)
                if r:
                    try:
                        try:
                            saison = "%s" %r.group("saison").zfill(2)
                            valid = 1
                        except:
                            saison = "01"
                        try:
                            numEpisode = "S%sE%s" %(saison, r.group("episode").zfill(4))
                        except:
                            numEpisode = ""

                    except Exception as e:
                        print(e)
                    nameFinal = name[:r.start()]
                    break
            if r:
                return [nameFinal, saison, numEpisode, year]
            else:
                return [name, "", "", year]

    def correctNom(self, title, tabRep=[]):
        title = unquote(title, encoding='latin-1', errors='replace')
        title = unicodedata.normalize('NFD', title).encode('ascii','ignore').decode("latin-1")
        tab_remp = [r'''\(.*\)|_|\[.*\]| FR |Episode| {2,}''', ' ']
        title = re.sub(tab_remp[0], tab_remp[1], title, flags=re.I)
        for repl in tabRep:
                title = title.replace(repl[0], repl[1])
        title = re.sub(r"^ \.?", "", title, flags=re.I)
        title = re.sub(r"\.{2,}", ".", title, flags=re.I)
        title = re.sub(r" {2,}", " ", title, flags=re.I)
        return title

    def nettNom(self, title, tabRep=[]):
        title = unquote(title, encoding='latin-1', errors='replace')
        title = unicodedata.normalize('NFD', title).encode('ascii','ignore').decode("latin-1")
        for repl in tabRep:
            title = title.replace(repl[0], repl[1])
        return title

    def testThread(self):
        a = 0
        tActif = True
        while tActif:
            tActif = False
            for t in threading.enumerate():
                if "tet" == t.getName():
                    tActif = True
            time.sleep(0.1)
            a += 1
            if a > 150:
                break
        return True

    def ventilationType(self, tabFiles, dictFile, paste, pasteCrypt, typM="", repCrypt=0):
        # ventilation films, serie divers
        tabUploaderAnime = ["[Tsundere-Raws]", "[DJB]", "-NanDesuKa", "[uP]", "[Pikari Teshima]", "[Kaerizaki-Fansub]", "Miracle Sharingan Fansub", "[Pikari-Teshima]", "[Team Arcedo]", "[matheousse]", "[NekoYu' - Team Arcedo]"]
        tabCorrect = [("[", "."), ("]", "."), ("{", "."), ("}", "."), (" ", "."), ("(", "."), (")", ".")]
        mDB = TMDB(KEYTMDB)
        cr = cryptage.Crypt()
        up = UptoLocal()

        for i, (nom, filecode, repo) in enumerate(tabFiles):
            numCrypt = cr.resolveLink(paste, filecode, cr=1)
            reso = up.reso(nom)
            filecode = pasteCrypt + "@" + numCrypt + "#" + reso

            uploaderAnime = False
            tabUA = [x for x in tabUploaderAnime if x in nom]
            if tabUA:
                for nn in tabUA:
                    nom = nom.replace(nn, "")
                uploaderAnime = True
            if filecode in dictFile.keys():
                recup = tuple([i] + list(dictFile[filecode]))
                mDB.tabMedia.append(recup)
            else:
                tmpNom = nom
                release = nom[:-4].replace(".", " ").replace("_", " ")
                nom = self.nettNom(nom, tabCorrect)
                #print(uploaderAnime)
                if nom[-4:] not in [".zip", ".rar", ".pdf", ".doc", ".xls", ".txt", ".mp3", ".nfo", ".jpg", ".png", ".JPG", ".PNG"]:
                    if typM:
                        if typM == "movie":
                            r = re.search(r"(TM)(?P<num>\d*)(TM)", nom)
                            if r:
                                numId = r.group("num")
                                threading.Thread(name="tet", target=mDB.movieNumId, args=(numId, filecode, i, release, repo)).start()
                            else:
                                title, year = self.extractInfo(nom, typM="movie")
                                threading.Thread(name="tet", target=mDB.searchMovie, args=(title, filecode, i, year, release, repCrypt, repo)).start()
                        else:
                            title, saison, episode, year = self.extractInfo(nom, typM="tvshow")
                            threading.Thread(name="tet", target=mDB.searchEpisode, args=(title, saison, episode, filecode, i, int(year), release, )).start()
                    else:
                        if re.search(r"s\d\d?\d?\.?e\d\d?\d?", nom, re.I) or uploaderAnime:
                            title, saison, episode, year = self.extractInfo(nom, typM="tvshow")
                            threading.Thread(name="tet", target=mDB.searchEpisode, args=(title, saison, episode, filecode, i, int(year), release, )).start()
                        elif re.search(r"\.19\d\d\.|\.20\d\d\.", nom):
                            title, year = self.extractInfo(nom, typM="movie")
                            threading.Thread(name="tet", target=mDB.searchMovie, args=(title, filecode, i, year, release)).start()
                        else:
                            mDB.tabMedia.append((i, tmpNom, '', 0, 0, 0, filecode, "divers"))
            if i % 500 == 0:
                time.sleep(1)
        self.testThread()
        medias = mDB.extractListe
        #notice(medias)
        return sorted(medias)

class MAJrep:

    def __init__(self):
        self.paste = "chc59xwg"
        self.pasteCrypt = "IBSfuEFS2"
        self.fileTotal = []
        self.typM = "movie"
        self.tabSql = []

    def extractRep(self):
        cnx = sqlite3.connect(BDREPO)
        cur = cnx.cursor()
        cur.execute("SELECT nom, fld, hsh FROM repPub")
        liste = cur.fetchall()
        cur.close()
        cnx.close()
        return liste

    def lastDateRep(self, nom):
        cnx = sqlite3.connect(BDREPO)
        cur = cnx.cursor()
        cur.execute("SELECT ddate FROM repoDate WHERE nom=?", (nom,))
        datLast = cur.fetchone()
        if datLast:
            datLast = datLast[0]
        else:
            datLast = '2002-05-10 01:31:02'
        cur.close()
        cnx.close()
        return datLast

    def gestionMajRep(self):
        liste = self.extractRep()
        for l in liste:
            threading.Thread(name="majRepCr", target=self.majRepFilm, args=(l[0], l[1], l[2],)).start()
            time.sleep(0.05)
        self.testThread()
        if self.fileTotal:
            self.inserDB()
            showInfoNotification("News arrivées!!")
        else:
            showInfoNotification("Pas de news!!")

    def testThread(self):
        a = 0
        tActif = True
        while tActif:
            tActif = False
            for t in threading.enumerate():
                if "majRepCr" == t.getName():
                    tActif = True
            time.sleep(0.1)
            a += 1
            if a > 150:
                break
        return True

    def majRepFilm(self, nom, folder, hsh):
        cr = cryptage.Crypt()
        datLast = self.lastDateRep(nom)
        hsh = cr.fldP(folder, hsh)
        folder = cr.cryptFolder(folder, crypt=0)
        up = UptoLocal()
        files, nbPages = up.getFilePublic(0, 100, folder, hsh)
        #notice(nbPages)
        fileTotalTmp = [x for x in files if x[0] > datLast]
        for pos in range(nbPages - 1, 0, -1):
            #notice("%s page %d" %(nom, pos))
            files, nbPages = up.getFilePublic(pos * 100, 100, folder, hsh)
            #notice(files)
            p1 = len(files)
            files = [x for x in files if x[0] > datLast]
            p2 = len(files)
            fileTotalTmp += files
            if p1 != p2:
                break
        fileTotalTmp = sorted(fileTotalTmp)
        if fileTotalTmp:
            self.tabSql.append("REPLACE INTO repoDate (nom, ddate) VALUES ('{}', '{}')".format(nom, fileTotalTmp[-1][0]))
            self.fileTotal += [list(x) + [nom] for x in fileTotalTmp]


    def inserDB(self):
        cnx = sqlite3.connect(BDREPO)
        cur = cnx.cursor()
        repCrypt = 1
        dictFile = {}
        for sql in self.tabSql:
            cur.execute(sql)
        cnx.commit()
        renam = RenameMedia()
        files = renam.ventilationType([x[1:] for x in self.fileTotal], dictFile, self.paste, self.pasteCrypt, self.typM, repCrypt)
        repCrypt = 1
        for f in files:
            f = list(f[1:])
            try:
                cur.execute("INSERT INTO filmsPub (numId, title, year, genre) VALUES (?, ?, ?, ?)", f[1:5])
            except sqlite3.Error as er:
                pass
            cur.execute("REPLACE INTO filmsPubLink (numId, link) VALUES (?, ?)", (f[1], f[5]))
            cur.execute("REPLACE INTO repPubFilm (nom, numId) VALUES (?, ?)", (f[-1], f[1], ))
        cnx.commit()
        cur.close()
        cnx.close()

class BDrepCrypt(RenameMedia):
    def __init__(self, database):
        RenameMedia.__init__(self)
        self.database = database

        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        cur.execute("""CREATE TABLE IF NOT EXISTS repBdCr(
          nom TEXT,
          folder TEXT,
          hsh TEXT,
          ddate TEXT,
          maj INTEGER DEFAULT 0,
          UNIQUE (nom, folder, hsh))
            """)
        cnx.commit()
        cur.execute("""CREATE TABLE IF NOT EXISTS repos(
          id INTEGER PRIMARY KEY,
          nom TEXT,
          title TEXT,
          numId INTEGER,
          saison INTEGER,
          episode INTEGER,
          lien TEXT,
          typM TEXT,
          repo TEXT,
          actif INTEGER DEFAULT 1,
          UNIQUE (lien))
            """)
        cnx.commit()
        cur.execute("""CREATE TABLE IF NOT EXISTS maj(
          nom TEXT,
          t INTEGER,
          UNIQUE (nom))
            """)
        cnx.commit()

        cur.close()
        cnx.close()

    def getMaj(self):
        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        cur.execute("SELECT t FROM maj")
        liste = cur.fetchone()
        cnx.commit()
        cur.close()
        cnx.close()
        if liste:
            return liste[0]
        else:
            return ""

    def updateMaj(self, t):
        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        cur.execute("REPLACE INTO maj (nom, t) VALUES ('maj', ?)", (t,))
        cnx.commit()
        cur.close()
        cnx.close()

    def getRepBdCr(self):
        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        cur.execute("SELECT nom, folder, hsh, ddate, maj FROM repBdCr")
        liste = cur.fetchall()
        cnx.commit()
        cur.close()
        cnx.close()
        return {x[1]: x for x in liste}

    def updateRepBdCr(self, nom, folder, hsh, maj="", ddate=""):
        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        if maj != "":
            cur.execute("UPDATE repBdCr set maj=? WHERE nom=? AND folder=? AND hsh=?", (maj, nom, folder, hsh,))
        if ddate:
            cur.execute("UPDATE repBdCr set ddate=? WHERE nom=? AND folder=? AND hsh=?", (ddate, nom, folder, hsh,))
        cnx.commit()
        cur.close()
        cnx.close()

    def insertRepBdCr(self, *argv):
        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        cur.execute("REPLACE INTO repBdCr (nom, folder, hsh, ddate, maj) VALUES (?, ?, ?, ?, ?)", argv)
        cnx.commit()
        cur.close()
        cnx.close()

    def insertRepoImport(self, *argv):
        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        cur.execute("REPLACE INTO repoImport (nom, fld, hsh, typImport) VALUES (?, ?, ?, ?)", argv)
        cnx.commit()
        cur.close()
        cnx.close()

    def getRepImport(self, typImport):
        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        cur.execute("SELECT fld, hsh FROM repoImport WHERE typImport=?", (typImport,))
        liste = cur.fetchall()
        cnx.commit()
        cur.close()
        cnx.close()
        return liste

    def getRepoMedias(self):
        cnx = sqlite3.connect(self.database)
        #cnx.text_factory = lambda s: str(s, "utf-8")
        cur = cnx.cursor()
        cur.execute("SELECT DISTINCT nom FROM seriesRepos")
        listeReposSeries = [x[0] for x in cur.fetchall() if x]
        cur.execute("SELECT DISTINCT nom FROM filmsRepos")
        listeReposFilms = [x[0] for x in cur.fetchall() if x]
        cur.execute("SELECT DISTINCT theme FROM divers")
        listeReposDivers = [x[0] for x in cur.fetchall() if x]
        cur.close()
        cnx.close()
        return listeReposFilms, listeReposSeries, listeReposDivers

    def getDatLast(self, repo):
        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        cur.execute("SELECT ddate FROM repoDate WHERE nom=?", (repo,))
        datLast = cur.fetchone()
        if datLast:
            datLast = datLast[0]
        else:
            datLast = '2002-05-10 01:31:02'
        cur.close()
        cnx.close()
        return datLast

    def insertRepFilm(self, repo, fileTotal, paste, pasteCrypt, numRep, hashRep):
        repCrypt = 1
        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        fileTotal = sorted(fileTotal)
        cur.execute("REPLACE INTO repoDate (nom, ddate) VALUES (?, ?)", (repo, fileTotal[-1][0],))
        cur.execute("REPLACE INTO repPub (nom, fld, hsh) VALUES (?, ?, ?)", (repo, numRep, hashRep,))
        cnx.commit()
        files = self.ventilationType([x[1:] for x in fileTotal], {}, paste, pasteCrypt, "movie", repCrypt)
        repCrypt = 1
        for f in files:
            f = list(f[1:])
            try:
                cur.execute("INSERT INTO filmsPub (numId, title, year, genre) VALUES (?, ?, ?, ?)", f[1:5])
            except sqlite3.Error as er:
                pass
            cur.execute("REPLACE INTO filmsPubLink (numId, link) VALUES (?, ?)", (f[1], f[5]))
            cur.execute("REPLACE INTO repPubFilm (nom, numId) VALUES (?, ?)", (repo, f[1], ))
        cnx.commit()
        cur.close()
        cnx.close()

    def insertRepSerie(self, lignes):
        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        for ligne in lignes:
            if ligne[-1] == "1":
                cur.execute("REPLACE INTO seriesPub (numId, title, year, genre) VALUES (?, ?, ?, ?)", ligne[2:6])
            else:
                try:
                    cur.execute("INSERT INTO seriesPub (numId, title, year, genre) VALUES (?, ?, ?, ?)", ligne[2:6])
                except sqlite3.Error as er:
                    pass
            try:
                cur.execute("REPLACE INTO seriesfolderHash (numId, folder, hsh) VALUES (?, ?, ?)", (ligne[2], ligne[6], ligne[7],))
            except:
                pass
            cur.execute("REPLACE INTO seriesRepos (nom, numId) VALUES (?, ?)", (ligne[8], ligne[2],))
        cnx.commit()
        cur.close()
        cnx.close()

    def insertRepDivers(self, lignes):
        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        for ligne in lignes:
            if ligne[5] == "1":
                cur.execute("REPLACE INTO divers (nom, title, folder, hsh, theme) \
                        VALUES (?, ?, ?, ?, ?,)", (ligne[1], ligne[2], ligne[3], ligne[4], ligne[6],))
            else:
                try:
                    cur.execute("INSERT INTO divers (nom, title, folder, hsh, theme) \
                            VALUES (?, ?, ?, ?, ?)", (ligne[1], ligne[2], ligne[3], ligne[4], ligne[6],))
                except sqlite3.Error as er:
                    pass
        cnx.commit()
        cur.close()
        cnx.close()

class ExtractRep:
    def __init__(self):
        self.filesF = []
        self.tabFolder = []
        self.up = UptoLocal()
        self.cr = cryptage.Crypt()

    def extractAll(self, liste):
        if liste:
            for folder, hsh in liste:
                threading.Thread(name="extRep", target=self.extractFolderCrypt, args=(folder, hsh,)).start()
                #self.extractFolderCrypt(folder, hsh)
                time.sleep(0.03)
            self.testThread("extRep")
            if self.tabFolder:
                for pages, folder, hsh in self.tabFolder:
                    for i in range(1, pages, 1):
                        threading.Thread(name="extRep", target=self.extractFiles, args=(folder, hsh, (i * 100), 0,)).start()
                        time.sleep(0.06)
                self.testThread("extRep")
            return self.filesF
        else:
            return []

    def extractFolderCrypt(self, folder, hsh):
        hsh = self.cr.fldP(folder, hsh)
        folder = self.cr.cryptFolder(folder, crypt=0)
        self.extractFiles(folder, hsh, offset=0)


    def extractFiles(self, folder, hsh, offset=0, ad=1):
        #notice(folder + " " + " " + hsh + " " + str(offset))
        files, infF = self.up.getFileSeries(offset, folder, hsh)
        if infF and infF[0] > 1 and ad:
            self.tabFolder.append(infF)
        paste = "chc59xwg"
        pasteCrypt = "IBSfuEFS2"
        filesF = []
        #notice(files)
        for nom, filecode in files:
            numCrypt = self.cr.resolveLink(paste, filecode, cr=1)
            reso = self.up.reso(nom)
            filecode = pasteCrypt + "@" + numCrypt + "#" + reso
            self.filesF.append((nom, filecode))
        return


    def extractFolderCryptOld(self, folder, hsh):
        hsh = self.cr.fldP(folder, hsh)
        folder = self.cr.cryptFolder(folder, crypt=0)
        files = self.up.getFileFolderPublicAll(folder, hsh)
        paste = "chc59xwg"
        pasteCrypt = "IBSfuEFS2"
        filesF = []
        for nom, filecode in files:
            numCrypt = self.cr.resolveLink(paste, filecode, cr=1)
            reso = self.up.reso(nom)
            filecode = pasteCrypt + "@" + numCrypt + "#" + reso
            self.filesF.append((nom, filecode))
        return

    def testThread(self, nom):
        a = 0
        tActif = True
        while tActif:
            tActif = False
            for t in threading.enumerate():
                if nom == t.getName():
                    tActif = True
            time.sleep(0.1)
            a += 1
            if a > 250:
                break
        return True

class ImportDBS:
    def __init__(self):
        self.tabImport = []
        self. textImport = "Rapport Import\n"

    def ajoutFoldercr(self, params):
        debTemps = time.time()
        bd = BDrepCrypt(BDREPO)
        histoFolder  = bd.getRepBdCr()
        dialog = xbmcgui.Dialog()
        ret = dialog.yesno('Listes', 'Repertoire par ?', nolabel="Liste", yeslabel="Unique")
        if not ret:
            repo = ADDON.getSetting("numHeberg")
            fileSauveBd = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/bd.txt')
            if not repo:
                repo = dialog.input("Numéro", type=xbmcgui.INPUT_ALPHANUM)
            if repo:
                debTemps = time.time()
                #resetBDhkNew(v=0)
                pDialog2 = xbmcgui.DialogProgressBG()
                pDialog2.create('M.A.J', 'Import Pastes...')
                heberg = ADDON.getSetting("heberg")
                a = time.time()
                notice("recup rentry/anote... ")
                if heberg == "Pastebin":
                    tx = getBdPastebin(repo)
                elif heberg == "Rentry":
                    tx = getBdRentry(repo)
                elif heberg == "RentryC":
                    cr = cryptage.Crypt()
                    tx = cr.idRentry(repo)[0]
                elif heberg == "Textup":
                    tx = getBdTextup(repo)
                elif heberg == "fichier":
                    if os.path.isfile(fileSauveBd):
                        with open(fileSauveBd, "r") as f:
                            tx = ast.literal_eval(f.read())
                    else:
                        tx = ""
                else:
                    tx = getBdAnotepad(repo)

                #sauvegarde liens bd =================================================
                if tx:
                    with open(fileSauveBd, "w") as f:
                        f.write(str(tx))
                else:
                    if os.path.isfile(fileSauveBd):
                        with open(fileSauveBd, "r") as f:
                            tx = f.read()
                            tx = [x for x in tx.splitlines() if len(x) > 10]
                            showInfoNotification("Restore liste BD")
                #=====================================================================

                lignes = [x.split("=") for x in tx.splitlines() if len(x.split("=")) == 3]

                notice("recup liste bd en %.2f" %(time.time() - a ))
                a = time.time()
                if lignes:
                    dictContrib = {x[0]: x[1:] for x in lignes}
                    for nom, (folder, hsh) in dictContrib.items():
                        try:
                            ddate = histoFolder[folder][3]
                        except:
                            ddate = ""
                        threading.Thread(name="downRepCr", target=self.recupBD, args=(folder, hsh.strip(), ddate, nom, )).start()
                        time.sleep(0.15)

                    self.testThreadActif("downRepCr")
                    notice("temps download: %.2f" %(time.time() - a))
                    a = time.time()
                    bd = BDrepCrypt(BDREPO)
                    for t in self.tabImport:
                        bd.insertRepBdCr(t[0], t[1], t[2], t[3], int(t[4]))
                    seriesOnContinue = joinDB(pDialog2)
                    notice("temps fusion bd: %.2f" %(time.time() - a))
                    a = time.time()
                    if int(ADDON.getSetting("intmaj")) and ADDON.getSetting("ochk1") != "false":
                        seriesOnContinue = list(set(seriesOnContinue))
                        extractEpisodesOnContinue(seriesOnContinue)
                    notice("Fin mep On Continue: %.2f" %(time.time() - a))
                pDialog2.close()
                dialog = xbmcgui.Dialog()
                ok = dialog.ok('Import', self.textImport)
        else:
            folder = dialog.input("Num Folder", type=xbmcgui.INPUT_ALPHANUM)
            if folder:
                hsh = dialog.input("Num Hash", type=xbmcgui.INPUT_ALPHANUM)
                if hsh:
                    nom = dialog.input("Position et nom ex: 08-goliath", type=xbmcgui.INPUT_ALPHANUM)
                    if nom:
                        debTemps = time.time()
                        for db in [x for x in os.listdir(CHEMIN) if x[:3] == "hk_"]:
                            xbmcvfs.delete(os.path.join(CHEMIN, db))
                        pDialog2 = xbmcgui.DialogProgressBG()
                        pDialog2.create('M.A.J', 'Import Pastes...')
                        a = time.time()
                        ddate = ""
                        threading.Thread(name="downRepCr", target=self.recupBD, args=(folder, hsh.strip(), ddate, nom,)).start()
                        time.sleep(0.1)
                        self.testThreadActif("downRepCr")
                        seriesOnContinue = joinDB(pDialog2)
                        seriesOnContinue = list(set(seriesOnContinue))
                        extractEpisodesOnContinue(seriesOnContinue)
                        pDialog2.close()
        showInfoNotification("Import ok en  %.2f s" %(time.time() - debTemps))

    def testThreadActif(self, nom):
        a = 0
        tActif = True
        while tActif:
            tActif = False
            for t in threading.enumerate():
                if nom == t.getName():
                    tActif = True
            time.sleep(0.1)
            a += 1
            if a > 1200:
                break
        return True

    def recupBD(self, folderIn, hshIn, ddate, nom, maj=0):

        try:
            a = time.time()
            folder, hsh = folderIn, hshIn
            up = UptoLocal()
            cr = cryptage.Crypt()
            hsh = cr.fldP(folder, hsh)
            folder = cr.cryptFolder(folder, crypt=0)
            tab = up.getFile(folder, hsh)
            if tab:
                of = False
                tab = [x for x in tab if "medias_" in x[1]]
                #notice(tab[0][0])
                #notice(ddate)
                if tab[0][0] != ddate:
                    for i in range(3):
                        if KEYUPTO:
                            url, ok = cr._linkDownloadUptobox(KEYUPTO, tab[0][2])
                        elif KEYALL:
                            url, ok = cr._linkDownloadAlldebrid(KEYALL, "https://%s/%s" %(EXTUPTO, tab[0][2]))
                        elif KEYREAL:
                            url, ok = cr._linkDownloadRealdebrid(KEYREAL, "https://%s/%s" %(EXTUPTO, tab[0][2]))
                        #notice(url + ' ' + str(ok))
                        if url:
                            break
                        time.sleep(0.1)
                    if url:
                        '''
                        if tab[0][1][-4:] == ".zip":
                            resume_header = {'Range': 'bytes=%d-' % 0}
                            response = requests.get(url, headers=resume_header, stream=True,  verify=True, allow_redirects=True)
                            handle = open(os.path.join(CHEMIN, tab[0][1]), "wb")
                            for chunk in response.iter_content(chunk_size=1024 * 30):
                                if chunk:  # filter out keep-alive new chunks
                                    handle.write(chunk)
                            notice(os.path.join(CHEMIN, tab[0][1]))
                            time.sleep(0.1)
                            with zipfile.ZipFile(os.path.join(CHEMIN, tab[0][1]), 'r') as zipObject:
                                zipObject.extract(tab[0][1].replace(".zip", ".db"), CHEMIN)
                            os.rename(tab[0][1].replace(".zip", ".db"), "hk_%s_%s.bd" %(nom, folderIn))
                        else:
                        '''
                        for i in range(3):
                            """
                            resume_header = {'Range': 'bytes=%d-' % 0}
                            response = requests.get(url, headers=resume_header, stream=True,  verify=True, allow_redirects=True)
                            handle = open(os.path.join(CHEMIN, "hk_%s_%s.bd" %(nom, folderIn)), "wb")
                            for chunk in response.iter_content(chunk_size=1024 * 30):
                                if chunk:  # filter out keep-alive new chunks
                                    handle.write(chunk)
                            """
                            try:
                                r = requests.get(url, timeout=3)
                                open(os.path.join(CHEMIN, "hk_%s_%s.bd" %(nom, folderIn)), 'wb').write(r.content)
                                time.sleep(0.1 + i * 0.2)
                                if os.path.isfile(os.path.join(CHEMIN, "hk_%s_%s.bd" %(nom, folderIn))):
                                    if testBD(os.path.join(CHEMIN, "hk_%s_%s.bd" %(nom, folderIn))) == "ok":
                                        ok = True
                                        break
                                else:
                                    time.sleep(0.1 + i * 0.2)
                            except:
                                time.sleep(0.1 + i * 0.2)
                        if ok:
                            #if update:
                            #    bd = BDrepCrypt(BDREPO)
                            #    bd.insertRepBdCr(nom, folderIn, hshIn, tab[0][0], maj)
                            self. textImport += "[COLOR green]%s[/COLOR] :: " %nom
                            self.tabImport.append((nom, folderIn, hshIn, tab[0][0], maj))
                        else:
                            self. textImport += "[COLOR red]%s[/COLOR] :: " %nom
                            showInfoNotification("Import ko hk_%s_%s.bd" %(nom, folderIn))
                            xbmcvfs.delete(os.path.join(CHEMIN, "hk_%s_%s.bd" %(nom, folderIn)))
                else:
                    self.textImport += "[COLOR yellow]%s[/COLOR] :: " %nom
            else:
                self.textImport += "[COLOR red]%s absente[/COLOR] :: " %nom
            notice("import %s en %.2f" %(nom, time.time() - a))
        except Exception as e:
            self. textImport += "[COLOR red]%s Pb import[/COLOR] :: " %nom
            notice("pb import db %s %s => %s" %(folderIn, hshIn, str(e)))

    def majHkNew(self):
        pDialog2 = xbmcgui.DialogProgressBG()
        pDialog2.create('M.A.J', 'Import Pastes...')
        a = time.time()
        for db in [x for x in os.listdir(CHEMIN) if x[:3] == "hk_"]:
            xbmcvfs.delete(os.path.join(CHEMIN, db))
        bd = BDrepCrypt(BDREPO)
        histoFolder  = bd.getRepBdCr()
        for nom, folder, hsh, ddate, maj in histoFolder.values():
            threading.Thread(name="downRepCr", target=self.recupBD, args=(folder, hsh, ddate, nom, maj)).start()
        self.testThreadActif("downRepCr")
        for t in self.tabImport:
            bd.insertRepBdCr(t[0], t[1], t[2], t[3], int(t[4]))
        joinDB(pDialog2)
        pDialog2.close()
        showInfoNotification("Import ok en  %.2f s" %(time.time() - a))
        bd.updateMaj(int(time.time()))



# ======================================================================================= fonctions ======================================================================
def extractEpisodesOnContinue(series=[]):
    notice("in onc ")
    notice(time.time())
    try:
        if ADDON.getSetting("bookonline") != "false":
            listeVus = widget.responseSite("http://%s/requete.php?name=%s&type=getvu" %(ADDON.getSetting("bookonline_site"), ADDON.getSetting("bookonline_name")))
        else:
            listeVus =  widget.getVu("tvshow")
    except:
        listeVus = []

    databaseTV = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/tvshow.bd')
    database = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/mediasNew.bd')
    if not databaseTV:
        update = "full"
    else:
        update = "update"
        cnxTV = sqlite3.connect(databaseTV)
        curTV = cnxTV.cursor()
        curTV.execute("""CREATE TABLE IF NOT EXISTS tvshowEpisodesInfos(
              id INTEGER PRIMARY KEY,
              numId INTEGER,
              title TEXT,
              overview TEXT,
              year TEXT,
              backdrop TEXT,
              popu REAL,
              saison INTEGER,
              episode INTEGER,
              UNIQUE (numId, saison, episode))
                """)

        curTV.execute("""CREATE TABLE IF NOT EXISTS tvshowEpisodes(
              id INTEGER PRIMARY KEY,
              numId INTEGER,
              saison INTEGER,
              episode INTEGER,
              link TEXT,
              UNIQUE (numId, saison, episode))
                """)
        cnxTV.commit()
        curTV.execute("SELECT DISTINCT numId FROM tvshowEpisodes")
        listeIn = [int(x[0]) for x in curTV.fetchall() if x[0]]
        curTV.close()
        cnxTV.close()
        listeVuId = [int(vu.split("-")[0]) for vu in listeVus]
        listeAjout = [x for x in listeVuId if x not in listeIn]
        cnx = sqlite3.connect(database)
        cur = cnx.cursor()
        cur.execute("SELECT numId FROM seriesFolderHash")
        listeNumIdBd = [int(x[0]) for x in cur.fetchall() if x[0]]
        cur.close()
        cnx.close()
        series += [x for x in listeAjout if x in listeNumIdBd]
    #notice(series)
    if series or not databaseTV:
        up = UptoLocal()
        cr = cryptage.Crypt()
        ren = RenameMedia()
        mdb = TMDB(KEYTMDB)

        cnxTV = sqlite3.connect(databaseTV)
        curTV = cnxTV.cursor()

        curTV.execute("""CREATE TABLE IF NOT EXISTS tvshowEpisodesInfos(
              id INTEGER PRIMARY KEY,
              numId INTEGER,
              title TEXT,
              overview TEXT,
              year TEXT,
              backdrop TEXT,
              popu REAL,
              saison INTEGER,
              episode INTEGER,
              UNIQUE (numId, saison, episode))
                """)

        curTV.execute("""CREATE TABLE IF NOT EXISTS tvshowEpisodes(
              id INTEGER PRIMARY KEY,
              numId INTEGER,
              saison INTEGER,
              episode INTEGER,
              link TEXT,
              UNIQUE (numId, saison, episode))
                """)

        cnxTV.commit()
        curTV.execute("SELECT numId, saison, episode FROM tvshowEpisodesInfos")
        tabEpisodesIn = curTV.fetchall()


        cnx = sqlite3.connect(database)
        cur = cnx.cursor()

        dictSerie = {}
        for vu in listeVus:
            vu = vu.split("-")
            episode = int(vu[1].zfill(2) + vu[2].zfill(4))
            if vu[0] in dictSerie.keys() and episode > dictSerie[vu[0]]:
                    dictSerie[vu[0]] = episode
            else:
                dictSerie[vu[0]] = episode
        if update == "update":
            dictSerie = {k: v for k, v in dictSerie.items() if int(k) in series}
        sqlSerieDetails = "REPLACE INTO tvshowEpisodesInfos (numId, title, overview, year, backdrop, popu, saison, episode) VALUES(?, ?, ?, ?, ?, ?, ?, ?)"
        sqlSerie = "REPLACE INTO tvshowEpisodes (numId, saison, episode, link) VALUES(?, ?, ?, ?)"
        if dictSerie:
            for numId, episodeVu in dictSerie.items():
                #notice(numId)
                #dictSaison = {}
                dictEpisodes = {}
                a = time.time()
                sql = "SELECT folder, hsh FROM seriesFolderHash WHERE numId={}".format(numId)
                cur.execute(sql)
                folders = cur.fetchall()
                resos = [""]
                groupes, cast, director, network = [], [], [], []
                try:
                    year = int(film[3])
                except:
                    year = 2010
                genre = []
                for j, (folder, hsh) in enumerate(folders):
                    b = time.time()
                    hsh = cr.fldP(folder, hsh)
                    folder = cr.cryptFolder(folder, crypt=0)
                    try:
                        tabFiles = up.getFileFolderPublicAll(folder, hsh)
                    except Exception as e:
                        tabFiles = []
                        notice("scraperUpto :: pb extraction folder %s" %str(e))
                    #notice("extract %.2f" %(time.time() - a))
                    #notice(len(tabFiles))
                    for name, link in tabFiles:
                        _, saison, episode, _ = ren.extractInfo(name)
                        if saison:
                            paste = "chc59xwg"
                            link = cr.resolveLink(paste, link, cr=1)
                            reso = up.reso(name)
                            episode = episode.split("E")[1]
                            if (int(numId), int(saison), int(episode)) not in tabEpisodesIn:
                                if int(saison) in dictEpisodes.keys():
                                    tabEpisodes = dictEpisodes[int(saison)]
                                else:
                                    tabEpisodes = mdb.saison(numId, int(saison))
                                    dictEpisodes[int(saison)] = tabEpisodes
                                #name, overview, dateRelease, backdrop, popu, numSaison, numEpisode
                                #notice(tabEpisodes)
                                infosEpisode = [x for x in tabEpisodes if int(episode) == x[-1]]
                                if infosEpisode:
                                    infosEpisode = infosEpisode[0]
                                else:
                                    infosEpisode = ["", "", "", "", "", int(saison), int(episode)]
                                curTV.execute(sqlSerieDetails, [numId] + infosEpisode)
                            else:
                                infosEpisode = []

                            curTV.execute(sqlSerie, (numId, int(saison), int(episode), "IBSfuEFS2@" + link + "#" + reso ))
                    #notice("insert %.2f" %(time.time() -a))
                    up.tabMedia = []
                cnxTV.commit()
                notice('Update "On continue" Ok!! %ds' %(time.time() - a))
            showInfoNotification('Update "On continue" Ok!! (%d series)' %len(dictSerie))
        else:
            showInfoNotification('pas update "On continue"')
        curTV.close()
        cnxTV.close()
        cur.close()
        cnx.close()

    #else:
    #    showInfoNotification('pas update "On continue"')
    notice("fin onc ")
    notice(time.time())

def reinitPoissonnerie():
    cnx = sqlite3.connect(BDREPO)
    cur = cnx.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS repos(
          id INTEGER PRIMARY KEY,
          nom TEXT,
          title TEXT,
          numId INTEGER,
          saison INTEGER,
          episode INTEGER,
          lien TEXT,
          typM TEXT,
          repo TEXT,
          actif INTEGER DEFAULT 1,
          UNIQUE (lien))
            """)
    cnx.commit()
    cur.execute("DELETE FROM repos WHERE repo='poissonnerie'")
    cnx.commit()
    cur.close()
    cnx.close()
    showInfoNotification("Poissonnerie effacée, bonne pêche!")

def createRepo(params):
    cr = cryptage.Crypt()
    repo = params["repo"]
    hsh = params["hash"]
    folder = params["folder"]
    hsh = cr.fldP(folder, hsh)
    folder = cr.cryptFolder(folder, crypt=0)
    cnx = sqlite3.connect(BDREPO)
    cur = cnx.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS repos(
          id INTEGER PRIMARY KEY,
          nom TEXT,
          title TEXT,
          numId INTEGER,
          saison INTEGER,
          episode INTEGER,
          lien TEXT,
          typM TEXT,
          repo TEXT,
          actif INTEGER DEFAULT 1,
          UNIQUE (lien))
            """)
    cnx.commit()
    cur.execute("SELECT nom, title, numId, saison, episode, lien, typM, repo FROM repos WHERE repo=?", (repo,))
    dictFile = {x[5]: x for x in cur.fetchall()}
    cur.execute("DELETE FROM repos WHERE nom=?", (repo,))

    paste = "chc59xwg"
    pasteCrypt = "IBSfuEFS2"
    up = UptoLocal()
    renam = RenameMedia()
    a = time.time()
    files = up.getFileFolderPublicAll(folder, hsh)
    a = time.time()
    files = renam.ventilationType([list(x) + ["posiion"] for x in files], dictFile, paste, pasteCrypt)
    for f in files:
        f = list(f[1:])
        if len(f) == 7:
            f.append(repo)
        cur.execute("REPLACE INTO repos (nom, title, numId, saison, episode, lien, typM, repo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", f)
    cnx.commit()
    cur.close()
    cnx.close()
    return

def extractFolderCrypt(folder, hsh):
    up = UptoLocal()
    cr = cryptage.Crypt()
    hsh = cr.fldP(folder, hsh)
    folder = cr.cryptFolder(folder, crypt=0)
    files = up.getFileFolderPublicAll(folder, hsh)
    paste = "chc59xwg"
    pasteCrypt = "IBSfuEFS2"
    filesF = []
    for nom, filecode in files:
        numCrypt = cr.resolveLink(paste, filecode, cr=1)
        reso = up.reso(nom)
        filecode = pasteCrypt + "@" + numCrypt + "#" + reso
        filesF.append((nom, filecode))
    return filesF


def cryptFolder():
    dialog = xbmcgui.Dialog()
    ret = dialog.yesno('Listes', 'Quel type de liste ?', nolabel="Films", yeslabel="Series")
    if not ret:
        #movies
        media = "1"
    else:
        media = "0"
    dialog = xbmcgui.Dialog()
    hashRep = dialog.input("HASH repertoire", type=xbmcgui.INPUT_ALPHANUM)
    if hashRep:
        numRep = dialog.numeric(0, 'Numéro Repertoire')
        if numRep:
            folder, hsh = _cryptFolder(numRep, hashRep)
            dialog = xbmcgui.Dialog()
            ret = dialog.ok("Numéros cryptés", "repertoire => %s\nHASH => %s" %(folder + media, hsh))
            return


def _cryptFolder(folder, hsh):
    cr = cryptage.Crypt()
    folder = cr.cryptFolder(folder, crypt=1)
    hsh = cr.fldP(folder, hsh)
    return folder, hsh

def gestionMajRep(params):
    cnx = sqlite3.connect(BDREPO)
    cur = cnx.cursor()
    cur.execute("SELECT nom, fld, hsh FROM repPub")
    liste = cur.fetchall()
    cur.close()
    cnx.close()
    tabNews = []
    for l in liste:
        a = time.time()
        newFilms = majRepFilm(l[0], l[1], l[2])
        if newFilms:
            tabNews.append(newFilms)
        notice(time.time() - a)
    if tabNews:
        showInfoNotification("News arrivées!!")
    else:
        showInfoNotification("Pas de news!!")

def majRepFilm(nom, folder, hsh):
    newFilms = False
    cnx = sqlite3.connect(BDREPO)
    cur = cnx.cursor()
    cr = cryptage.Crypt()
    typM = folder[-1]
    folder = folder[:-1]
    typM = "movie"
    hsh = cr.fldP(folder, hsh)
    folder = cr.cryptFolder(folder, crypt=0)
    paste = "chc59xwg"
    pasteCrypt = "IBSfuEFS2"
    up = UptoLocal()
    renam = RenameMedia()
    cur.execute("SELECT ddate FROM repoDate WHERE nom=?", (nom,))
    datLast = cur.fetchone()
    if datLast:
        datLast = datLast[0]
    else:
        datLast = '2002-05-10 01:31:02'
    files, nbPages = up.getFilePublic(0, 100, folder, hsh)
    fileTotal = [x for x in files if x[0] > datLast]
    for pos in range(nbPages - 1, 0, -1):
        notice("%s page %d" %(nom, pos))
        files, nbPages = up.getFilePublic(pos * 100, 100, folder, hsh)
        p1 = len(files)
        files = [x for x in files if x[0] > datLast]
        p2 = len(files)
        fileTotal += files
        if p1 != p2:
            break
    dictFile = {}

    if fileTotal:
        newFilms = True
        repCrypt = 1
        fileTotal = sorted(fileTotal)
        cur.execute("REPLACE INTO repoDate (nom, ddate) VALUES (?, ?)", (nom, fileTotal[-1][0],))
        cnx.commit()
        files = renam.ventilationType([x[1:] for x in fileTotal], dictFile, paste, pasteCrypt, typM, repCrypt)
        repCrypt = 1
        #notice(files)
        for f in files:
            f = list(f[1:])
            try:
                cur.execute("INSERT INTO filmsPub (numId, title, year, genre) VALUES (?, ?, ?, ?)", f[1:5])
            except sqlite3.Error as er:
                pass
            cur.execute("REPLACE INTO filmsPubLink (numId, link) VALUES (?, ?)", (f[1], f[5]))
    cnx.commit()
    cur.close()
    cnx.close()
    return newFilms

def updateSeriesRepCR():
    up = UptoLocal()
    bd = BDrepCrypt(BDREPO)
    liste = bd.getRepImport("liste")
    for numRep, hashRep in liste:
        cr = cryptage.Crypt()
        hsh = hashRep
        folder = numRep
        hsh = cr.fldP(folder, hsh)
        folder = cr.cryptFolder(folder, crypt=0)
        tab = up.getFile(folder, hsh)
        url, _ = cr._linkDownloadUptobox(KEYUPTO, tab[0][2])
        r = requests.get(url, allow_redirects=True)
        lignes = [x.split(";") for x in r.content.decode('latin-1').splitlines()]
        lignesSeries = [x for x in lignes if x[0] == "serie"]
        bd.insertRepSerie(lignesSeries)
        showInfoNotification("Update rep Series Ok!!")

def resetBDhkNew(v=1):
    cnx = sqlite3.connect(BDREPO)
    cur = cnx.cursor()
    sql = "DELETE FROM repBdCr"
    cur.execute(sql)
    cnx.commit()
    cur.close()
    cnx.close()
    xbmcvfs.delete(os.path.join(CHEMIN, "mediasNew.bd"))
    xbmcvfs.delete(os.path.join(CHEMIN, "combine.db"))
    for db in [x for x in os.listdir(CHEMIN) if x[:3] == "hk_"]:
        xbmcvfs.delete(os.path.join(CHEMIN, db))
    if v:
        showInfoNotification("bd effacée")


def ajoutFoldercr(params):
    iDB = ImportDBS()
    iDB.ajoutFoldercr(params)

def majHkNew():
    iDB = ImportDBS()
    iDB.majHkNew()


def testThreadActif(nom):
    a = 0
    while 1:
        tabTh = [t for t in threading.enumerate() if nom == t.getName()]
        if not tabTh:
            break
        time.sleep(0.1)
        a += 1
        if a > 1800:
            break
    return True

def lastMaj():
    bd = BDrepCrypt(BDREPO)
    return bd.getMaj()


def majHkcron():
    threading.Thread(name="maj", target=scraperUPTO.majHkNewStart).start()

def majHkNewStart():
    a = time.time()
    iDB = ImportDBS()
    for db in [x for x in os.listdir(CHEMIN) if x[:3] == "hk_"]:
        xbmcvfs.delete(os.path.join(CHEMIN, db))
    bd = BDrepCrypt(BDREPO)
    histoFolder  = bd.getRepBdCr()
    for nom, folder, hsh, ddate, maj in histoFolder.values():
        threading.Thread(name="downRepCr", target=iDB.recupBD, args=(folder, hsh, ddate, nom, maj)).start()
    testThreadActif("downRepCr")
    seriesOnContinue = joinDB(None)
    for t in iDB.tabImport:
        #notice(iDB.tabImport)
        bd.insertRepBdCr(t[0], t[1], t[2], t[3], int(t[4]))
    notice("on continue")
    seriesOnContinue = list(set(seriesOnContinue))
    #notice(seriesOnContinue)
    extractEpisodesOnContinue(seriesOnContinue)
    notice("fin OnContinue")
    #bd.updateMaj(int(time.time()))


def joinDB(pDialog2):
    a = time.time()
    actu = 0
    bd = BDrepCrypt(BDREPO)
    histoFolder = bd.getRepBdCr()
    histoFolder = {x[1]: x for x in histoFolder.values()}

    cnx = sqlite3.connect(os.path.join(CHEMIN,"combine.db"))
    cur = cnx.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS seriesPub(
                id INTEGER PRIMARY KEY,
                numId INTEGER,
                title TEXT,
                overview TEXT,
                poster TEXT,
                year TEXT,
                genres TEXT,
                backdrop TEXT,
                popu REAL,
                votes INTEGER,
                dateRelease TEXT,
                runtime INTEGER,
                lang TEXT,
                logo TEXT,
                saga INTEGER,
                certif INTEGER,
                imdb TEXT,
                maj INTEGER,
                actif INTEGER default 1,
                UNIQUE (numId))
              """)
    cur.execute("""CREATE TABLE IF NOT EXISTS seriesfolderHash(
          id INTEGER PRIMARY KEY,
          numId INTEGER,
          folder TEXT,
          hsh TEXT,
          actif INTEGER DEFAULT 1,
          UNIQUE (numId, folder, hsh))
            """)
    cur.execute("""CREATE TABLE IF NOT EXISTS seriesRepos(
          nom TEXT,
          numId INTEGER,
          actif INTEGER DEFAULT 1,
          UNIQUE (nom, numId))
            """)
    cur.execute("""CREATE TABLE IF NOT EXISTS numMaj(
          num INTEGER,
          nom TEXT,
          UNIQUE (nom))""")
    cur.execute("""CREATE TABLE IF NOT EXISTS filmsPub(
            id INTEGER PRIMARY KEY,
            numId INTEGER,
            title TEXT,
            overview TEXT,
            poster TEXT,
            year TEXT,
            genres TEXT,
            backdrop TEXT,
            popu REAL,
            votes INTEGER,
            dateRelease TEXT,
            runtime INTEGER,
            lang TEXT,
            logo TEXT,
            saga INTEGER,
            certif INTEGER,
            imdb TEXT,
            maj INTEGER,
            actif INTEGER default 1,
            UNIQUE (numId))
          """)
    cur.execute("""CREATE TABLE IF NOT EXISTS filmsPubLink(
          id INTEGER PRIMARY KEY,
          numId INTEGER,
          link TEXT,
          UNIQUE (numId, link))
            """)
    cur.execute("""CREATE TABLE IF NOT EXISTS filmsRepos(
          famille TEXT,
          nom TEXT,
          numId INTEGER,
          actif INTEGER DEFAULT 1,
          UNIQUE (famille, nom, numId))
            """)
    cur.execute("""CREATE TABLE IF NOT EXISTS divers(
        id INTEGER PRIMARY KEY,
        nom TEXT,
        title TEXT,
        folder TEXT,
        hsh TEXT,
        theme TEXT,
        maj INTEGER,
        actif INTEGER default 1,
        UNIQUE (nom))
          """)
    i = 1
    listDB = sorted([x for x in os.listdir(CHEMIN) if x[:3] == "hk_"])
    notice(listDB)
    newListeFilm = []
    newListeSerie = []
    serieOnContinue = []
    for db in listDB:
        folder = db[:-3].split("_")[2]
        numMaj = histoFolder[folder][-1]

        nbGroupe = int((i / len(listDB)) * 100.0)
        nbGroupe = int(str(nbGroupe).split(".")[0])
        if pDialog2:
            pDialog2.update(nbGroupe, 'M.A.J', message=str(i))
        i += 1

        db = os.path.join(CHEMIN, db)
        if testBD(db) == "ok":
            notice(db)
            try:
                cnx2 = sqlite3.connect(db)
                cur2 = cnx2.cursor()

                # films
                cur2.execute("SELECT numId, title, overview, poster, year, genres, backdrop, popu, votes, dateRelease, runTime, lang, logo, saga, certif, imdb, maj, actif FROM filmsPub WHERE maj>?" , (numMaj,))
                liste = cur2.fetchall()
                if liste:
                    newListeFilm += [x[3] for x in liste]
                    cur.executemany("REPLACE INTO filmsPub (numId, title, overview, poster, year, genres, backdrop, popu, votes, dateRelease, runTime, lang, logo, saga, certif, imdb, maj, actif) \
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", liste)

                    cur2.execute("SELECT famille, nom, numId, actif FROM filmsRepos")
                    cur.executemany("REPLACE INTO filmsRepos (famille, nom, numId, actif) VALUES (?, ?, ?, ?)", cur2.fetchall())

                    cur.executemany("REPLACE INTO filmsPubLink (numId, link) VALUES (?, ?)", cur2.execute("SELECT numId, link FROM filmsPubLink"))
                    actu = 1

                # series
                cur2.execute("SELECT numId, title, overview, poster, year, genres, backdrop, popu, votes, dateRelease, runTime, lang, logo, saga, certif, imdb, maj, actif FROM seriesPub WHERE maj>?" , (numMaj,))
                liste = cur2.fetchall()
                if liste:
                    newListeSerie += [x[3] for x in liste]
                    serieOnContinue += [x[0] for x in liste]
                    cur.executemany("REPLACE INTO seriesPub (numId, title, overview, poster, year, genres, backdrop, popu, votes, dateRelease, runTime, lang, logo, saga, certif, imdb, maj, actif) \
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", liste)

                    cur2.execute("SELECT nom, numId, actif FROM  seriesRepos")
                    cur.executemany("REPLACE INTO seriesRepos (nom, numId, actif) VALUES (?, ?, ?)", cur2.fetchall())

                    cur2.execute("SELECT numId, folder, hsh, actif FROM  seriesfolderHash")
                    cur.executemany("REPLACE INTO seriesfolderHash (numId, folder, hsh, actif) VALUES (?, ?, ?, ?)", cur2.fetchall())
                    actu = 1

                #divers
                cur2.execute("SELECT nom, title, folder, hsh, theme, maj, actif FROM divers WHERE maj>?" , (numMaj,))
                cur.executemany("REPLACE INTO divers (nom, title, folder, hsh, theme, maj, actif) VALUES (?, ?, ?, ?, ?, ?, ?)", cur2.fetchall())



                cur2.execute("SELECT num FROM  numMaj")
                try:
                    newMaj = cur2.fetchone()[0]
                except:
                    newMaj = 0
                bd.updateRepBdCr(histoFolder[folder][0], histoFolder[folder][1], histoFolder[folder][2], maj=newMaj)
                cnx.commit()
                cur2.close()
                cnx2.close()
            except Exception as e:
                notice("pb compilation db %s => %s" %(db, str(e)))
        else:
            showInfoNotification("Pb DB %s" %db)

    cur.close()
    cnx.close()

    bdOk = False
    for nbImport in range(3):
        xbmcvfs.delete(os.path.join(CHEMIN,"mediasNew.bd"))
        time.sleep(0.1)
        xbmcvfs.copy(os.path.join(CHEMIN,"combine.db"), os.path.join(CHEMIN,"mediasNew.bd"))
        time.sleep(0.1)
        if testBD(os.path.join(CHEMIN,"mediasNew.bd")) == "ok":
            bdOk = True
            break
        time.sleep(2)
    notice(time.time() - a)
    if actu and not pDialog2:
        cnx = sqlite3.connect(os.path.join(CHEMIN, "mediasNew.bd"))
        cur = cnx.cursor()

        listeTest = []
        if newListeFilm:
            sql = "SELECT poster FROM filmsPub ORDER BY id DESC LIMIT {} OFFSET 0".format(len(list(set(newListeFilm))))
            cur.execute(sql)
            listeTest = [x[0] for x in cur.fetchall()]

        listeTest1 = []
        if newListeSerie:
            sql = "SELECT poster FROM seriesPub ORDER BY id DESC LIMIT {} OFFSET 0".format(len(list(set(newListeSerie))))
            cur.execute(sql)
            listeTest1 = [x[0] for x in cur.fetchall()]

        cur.close()
        cnx.close()

        if ADDON.getSetting("rskin") != "false":
            if not xbmc.Player().isPlaying():
                xbmc.executebuiltin('ReloadSkin')
                time.sleep(0.5)
                xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.ExecuteAction","params":{"action":"back"},"id":1}')
            else:
                with open(xbmcvfs.translatePath('special://home/addons/plugin.video.sendtokodiU2P/rskin.txt'), "w") as f:
                    f.write("reload")
        #window = PopupWindowNew(xbmcvfs.translatePath('special://home/addons/plugin.video.sendtokodiU2P/icon.png'), list(set(newListeFilm)), list(set(newListeSerie)))
        if ADDON.getSetting("affmaj") != "false":
            window = PopupWindowNew(xbmcvfs.translatePath('special://home/addons/plugin.video.sendtokodiU2P/icon.png'), listeTest, listeTest1)
            window.show()
            xbmc.sleep(15000)
            window.close()
            del window
    #elif not pDialog2:
    #    window = PopupWindowNew(xbmcvfs.translatePath('special://home/addons/plugin.video.sendtokodiU2P/icon.png'), listeTest, listeTest1)
    #    window.show()
    #    xbmc.sleep(15000)
    #    window.close()
    #    del window
    with open(xbmcvfs.translatePath('special://home/addons/plugin.video.sendtokodiU2P/newserie.txt'), "a") as f:
        f.write("\n".join([str(x) for x in serieOnContinue]))
        if serieOnContinue:
            f.write("\n")
    return serieOnContinue

def testBD(bd):
    try:
        cnx = sqlite3.connect(bd)
        cur = cnx.cursor()
        cur.execute("PRAGMA integrity_check")
        result = cur.fetchone()[0]
        cur.close()
        cnx.close()
        return result
    except:
        return "ko"


if __name__ == '__main__':
    #folder=766771131 hash=DcCPWn6E33pVNIh6
    print(_cryptFolder("633667711", "59912177e16ebfa9"))

    sys.exit()
    a = time.time()
    maj = 'False'
    folder, hsh = "633667711", "59912177e16ebfa9"
    repo = folder + hsh
    cnx = sqlite3.connect("testRepos.bd")
    cur = cnx.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS repos(
          id INTEGER PRIMARY KEY,
          nom TEXT,
          title TEXT,
          numId INTEGER,
          saison INTEGER,
          episode INTEGER,
          lien TEXT,
          typM TEXT,
          repo TEXT,
          actif INTEGER DEFAULT 1,
          UNIQUE (lien))
            """)
    cur.execute("""CREATE TABLE IF NOT EXISTS repoDate(
          nom TEXT,
          ddate TEXT,
          UNIQUE (nom))
            """)
    cnx.commit()
    cur.execute("SELECT ddate FROM repoDate WHERE nom=?", (repo,))
    datLast = cur.fetchone()
    if datLast:
        datLast = datLast[0]
    else:
        datLast = '2002-05-10 01:31:02'
    cur.execute("SELECT nom, title, numId, saison, episode, lien, typM, repo FROM repos")
    dictFile = {x[5]: x for x in cur.fetchall()}
    if maj == "false":
        cur.execute("DELETE FROM repos")
        cur.execute("DELETE FROM repoDate WHERE nom=?", (repo,))

    paste = "chc59xwg"
    pasteCrypt = "IBSfuEFS2"
    up = UptoLocal()
    renam = RenameMedia()
    a = time.time()
    files, nbPages = up.getFilePublic(0, 100, folder, hsh)
    fileTotal = [x for x in files if x[0] > datLast]
    for pos in range(nbPages - 1, 0, -1):
        print(pos)
        files, nbPages = up.getFilePublic(pos * 100, 100, folder, hsh)
        p1 = len(files)
        files = [x for x in files if x[0] > datLast]
        p2 = len(files)
        fileTotal += files
        if p1 != p2:
            break
    if fileTotal:
        fileTotal = sorted(fileTotal)
        cur.execute("REPLACE INTO repoDate (nom, ddate) VALUES (?, ?)", (repo, fileTotal[-1][0],))
        cnx.commit()
        print(len(dictFile))
        files = renam.ventilationType([x[1:] for x in fileTotal], dictFile, paste, pasteCrypt)
        for f in files:
            f = list(f[1:])
            if len(f) == 7:
                f.append(repo)
            cur.execute("REPLACE INTO repos (nom, title, numId, saison, episode, lien, typM, repo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", f)
    cnx.commit()
    cur.close()
    cnx.close()
    print(time.time() - a)