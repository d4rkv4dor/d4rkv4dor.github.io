import requests
import re
from util import *

class AllDebridClient:

    def __init__(self, api_key, proxy, agent="u2p"):
        self.api_key = api_key
        self.agent = agent
        self.proxy = proxy
        self.BASE_URL = f"{proxy}https://api.alldebrid.com/v4.1"
        self.session = requests.Session()

    def _get(self, endpoint, params):
        r = self.session.post(
            f"{self.BASE_URL}{endpoint}",
            params={"agent": self.agent, "apikey": self.api_key, **params},
        )
        return r.json()

    def _post(self, endpoint, data):
        headers = {
            "Authorization": f"Bearer {self.api_key}"
        }
        r = self.session.post(
            f"{self.BASE_URL}{endpoint}",
            headers=headers,
            data=data
        )
        return r.json()

    def upload_magnets(self, magnets):
        data = [("magnets[]", m) for m in magnets]
        return self._post("/magnet/upload", data)

    def delete_magnet(self, magnet_id):
        for m in magnet_id:
            data = [("id", m)]
            self._post("/magnet/delete", data)
        return True

    def unlock(self, link):
        r = self._get("/link/unlock", {"link": link})
        if r.get("status") != "success":
            error_msg = r.get('error', {}).get('message', 'Erreur inconnue')
            print(f"Erreur Alldebrid: {error_msg}")
            return False, error_msg
        else:
            return True, r["data"]["link"]

    def magnet_status(self, magnet_id):
        url = self.BASE_URL + "/magnet/status"
        params = {
            "agent": self.agent,
            "apikey": self.api_key,
            "id": magnet_id
        }
        r = self.session.post(url, params=params)
        return r.json()

    def get_ready_files(self):
        status = self.status()  # inchangé volontairement

        ready = []
        for magnet in status.get("magnets", []):
            if magnet.get("status") == "Ready" and "links" in magnet:
                ready.append(magnet)

        return ready

    def find_links(self, entries):
        links = []
        for item in entries:
            if "e" in item:
                links.extend(self.find_links(item["e"]))
            else:
                if item.get("s", 0) <= 1_000_000:
                    continue

                link = item.get("l")
                if link:
                    links.append(link)
        return links

    def getLinksHash(self, hsh, saison="", episode=""):
        tabLinks = []
        rep = self.upload_magnets([hsh])
        magnet_id = rep["data"]["magnets"][0]["id"]
        rep = self.magnet_status(magnet_id)
        if rep.get("data", None):
            self.parser = NameParserSeries()
            try:
                if saison and episode:
                    tabLinks = self.find_episode_link(rep["data"]["magnets"]["files"], saison, episode)
                else:
                    tabLinks = self.find_links(rep["data"]["magnets"]["files"])
            except Exception as e:
                notice("alldeb getLinksHash %s" %e)
                tabLinks = []
        return tabLinks, magnet_id


    def find_episode_link(self, entries, saisonIn, episodeIn):

        for item in entries:
            if "e" in item:
                link = self.find_episode_link(item["e"], saisonIn, episodeIn)
                if link:
                    return link

            else:
                if item.get("s", 0) <= 1_000_000:
                    continue

                s, e, ok = self.parser.parse(
                    item.get("n", ""),
                    int(saisonIn),
                    int(episodeIn)
                )
                #notice([s, e, ok, item.get("l")])
                if ok and s == int(saisonIn) and e == int(episodeIn):
                    return [item.get("l")]

        return None



class NameParserSeries:

    CLEAN_PATTERNS = [
        r'\b(480p|720p|1080p|2160p|4K|8K)\b',
        r'\b(x264|x265|h264|h265|hevc|avc|xvid|divx)\b',
        r'\b(HDR10\+?|HDR|DV|DolbyVision)\b',
        r'\b(AAC|AC3|DDP?|EAC3|DTS(?:-HD)?|TRUEHD|FLAC|MP3)\b',
        r'\b(5\.1|7\.1|2\.0)\b',
        r'\b(TRUEFRENCH|FRENCH|MULTI|VOSTFR|VFQ|VO|VFF|MULTIFRENCH)\b',
        r'\b(BluRay|BDRip|BRRip|WEB[- ]?DL|WEBRip|HDRip|HDTV|CAM|TS)\b',
        r'-[A-Za-z0-9]+$',
    ]

    EP_PATTERNS = [
        r'(?i)\bS(?P<season>\d{1,2})[.\-_ ]*E[P]?(?P<episode>\d{1,4})\b',
        r'(?i)\b(?P<season>\d{1,2})[xX](?P<episode>\d{1,4})\b',
        r'(?i)\b(?:season|saison)\s*(?P<season>\d{1,2})\s*(?:episode|ep)\s*(?P<episode>\d{1,4})\b',
        r'(?i)\bS(?P<season>\d{1,2})\b',
        r'(?i)\bE(?P<episode>\d{1,4})\b',
    ]

    def parse(self, name, saisonIn, episodeIn):
        cleaned = self._clean(name)
        saison = None
        episode = None
        cut_pos = len(cleaned)

        for pattern in self.EP_PATTERNS:
            match = re.search(pattern, cleaned)
            if match:
                if 'season' in match.groupdict():
                    saison = int(match.group('season'))
                if 'episode' in match.groupdict():
                    episode = int(match.group('episode'))
                cut_pos = match.start()
                break

        title = cleaned[:cut_pos].strip(" .-_")
        rep = False
        if saison and saison == saisonIn:
            if not episode or episode == episodeIn:
                rep = True

        return saison, episode, rep

    def _clean(self, name):
        name = name.replace('.', ' ').replace('_', ' ')
        for pattern in self.CLEAN_PATTERNS:
            name = re.sub(pattern, '', name, flags=re.IGNORECASE)
        return re.sub(r'\s+', ' ', name).strip()