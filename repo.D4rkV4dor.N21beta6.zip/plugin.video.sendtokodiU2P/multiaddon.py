import xbmcgui
import threading
from concurrent.futures import ThreadPoolExecutor
from wastream import WaStream
from streamfusion import StreamFusion
from comet import Comet
import json
import io
from util import *
import os
import xbmcvfs
import requests



try:
    xbmcvfs.mkdirs(xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/addons'))
except: pass
KEYTMDB = ADDON.getSetting("apikey")

class LinksMultiAddons:
    def __init__(self, addons):
        self.addons = addons
        #notice(addons)
        self.max_workers = len(self.addons)
        names = [k for k, v  in self.addons.items() if k not in ("tmdb_id", "typ")]
        self.dictClasse = {"WaStream": WaStream, "StreamFusion": StreamFusion, "Comet": Comet}
        self.typ = addons["typ"]
        self.imdb_id = self.getIMDB(addons["tmdb_id"], self.typ)
        #notice(self.imdb_id)
        self.run_all_parallel(names)

    def _notify(self, title, msg):
        xbmcgui.Dialog().notification(title, msg, xbmcgui.NOTIFICATION_INFO, 3000)
        #print(title, msg)

    def getIMDB(self, id_tmdb, typ="movie"):
        url = f"https://api.themoviedb.org/3/{typ}/{id_tmdb}/external_ids?api_key={KEYTMDB}"
        data = requests.get(url, timeout=5).json()
        imdb_id = data.get("imdb_id")
        return imdb_id


    def _run_provider(self, name):
        try:
            cls = self.dictClasse[self.addons.get(name).get("cls")]

            if not cls:
                self._notify("Erreur", "Provider inconnu: " + name)
                return None

            obj = cls(self.addons.get(name).get("url"))

            if self.typ == "movie":
                result = obj.getMovie(self.imdb_id)
            else:
                result = obj.getSerie(self.imdb_id, self.addons.get(name).get("saison"), self.addons.get(name).get("episode"))
            self._notify("%d resultats" %len(result), name)

            #notice([name, result])
            return name, result
        except Exception as e:
            notice(f"Provider {name} error: {e}")
            return name, None

    def writeJson(self, resultats):

        filename = f"{self.imdb_id}.json"
        with io.open(os.path.join(xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/addons'), filename), "w", encoding="utf-8") as f:
            json.dump(resultats, f, ensure_ascii=False, indent=4)


    def run_all_parallel(self, items):
        self.results = {}

        def worker():
            with ThreadPoolExecutor(max_workers=self.max_workers) as pool:
                for name, result in pool.map(self._run_provider, items):
                    self.results[name] = result
            self.writeJson(self.results)

        t = threading.Thread(target=worker)
        t.start()
        #t.join() # attente de fin de resultats


if __name__ == "__main__":
    idimdb = "tt26443597"
    typ = "movie"
    urlwa = ""
    urlsf = ""

    addons = {"wastream": {"cls": WaStream, "url": urlwa, "id": idimdb, "t": typ},
            "streamfusion": {"cls": StreamFusion, "url": urlsf, "id": idimdb, "t": typ}}


    LinksMultiAddons(addons)
    print("fini")
    #print(resultats.results)
    #manager.run_all_parallel(urls)
