# -*- coding: utf-8 -*-
import json
import os
import sys
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import xbmcplugin
import pyxbmct
import requests
import io
import unicodedata
import re
import ast
import sqlite3
import shutil
import time
from medias import Media, TMDB
import medias
import zipfile
import threading
import datetime
from upNext import upnext_signal
import widget
from datetime import datetime
from datetime import timedelta
import createbdhk
import uptobox
try:
    # Python 3
    from urllib.parse import parse_qsl
    from util import *
except ImportError:
    from urlparse import parse_qsl
try:
    # Python 3
    from urllib.parse import unquote, urlencode, quote
    unichr = chr
except ImportError:
    # Python 2
    from urllib import unquote, urlencode, quote
try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

pyVersion = sys.version_info.major
pyVersionM = sys.version_info.minor
import cryptPaste2 as cryptage
import scraperUPTO


from cryptPaste import Crypt
from apiTraktHK import TraktHK, actifTrakt
try:
    BDMEDIA = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/medias.bd')
    BDMEDIANew = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/mediasNew.bd')

except: pass
from util import *

__addon__ = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
KEYALLDEB = __addon__.getSetting("keyalldebrid")
__handle__ = int(sys.argv[1])
__keyTMDB__ = __addon__.getSetting("apikey")
#bdKodis = ["MyVideos119.db", "MyVideos121.db", "MyVideos122.db", "MyVideos123.db"]
bdKodis = [x for x in os.listdir(xbmcvfs.translatePath("special://home/userdata/Database/")) if "MyVideos" in x]
for bdKodi in bdKodis:
    if os.path.isfile(xbmcvfs.translatePath("special://home/userdata/Database/%s" %bdKodi)):
        __database__ = xbmcvfs.translatePath("special://home/userdata/Database/%s" %bdKodi)
from alldeb import AllDebridClient
import torrent
from wastream import WaStream
from streamfusion import StreamFusion
from multiaddon import LinksMultiAddons

def gestionBD(*argvs):
    cnx = sqlite3.connect(xbmcvfs.translatePath('special://home/addons/plugin.video.sendtokodiU2P/resources/serie.db'))
    cur = cnx.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS serie(
                      `id`    INTEGER PRIMARY KEY,
                      numId TEXT,
                      title TEXT,
                      saison TEXT,
                      reso TEXT,
                      pos INTEGER,
                      UNIQUE (numId, title, saison))
                        """)
    cnx.commit()
    if argvs[0] == "update":
        cur.execute("REPLACE INTO serie (numId, title, saison, reso, pos) VALUES (?, ?, ?, ?, ?)", argvs[1:])
        cnx.commit()
        return True
    elif argvs[0] == "get":
        cur.execute("SELECT reso FROM serie WHERE title=? AND saison=?", argvs[1:])
        reso = cur.fetchone()
        return reso
    elif argvs[0] == "getHK":
        cur.execute("SELECT reso FROM serie WHERE numId=? AND saison=?", argvs[1:])
        reso = cur.fetchone()
        return reso
    elif argvs[0] == "last":
        cur.execute("SELECT numId, title, saison, reso FROM serie ORDER BY id DESC LIMIT 1")
        liste = cur.fetchone()
        if liste:
            return liste
        else:
            return ["", "", "", ""]
    cur.close()
    cnx.close()


def nettHistoDB(bd):
    cnx2 = sqlite3.connect(bd)
    cur2 = cnx2.cursor()
    try:
        cur2.execute("SELECT (SELECT f.strFilename FROM files as f WHERE b.idFile=f.idFile) FROM bookmark as b")
    except: pass
    try:
        [cur2.execute("DELETE FROM files WHERE strFilename=?", (x[0],)) for x in cur2.fetchall() if "playMediaUptobox&" not in x[0]]
    except: pass
    cnx2.commit()
    cur2.close()
    cnx2.close()

def getresos():
    resos = [__addon__.getSetting("resos")]
    timing = __addon__.getSetting("autoplay_delay")
    return resos, timing

def testCertification(numId, typMedia):
    if __addon__.getSetting("bookonline") != "false":
        try:
            passwd = __addon__.getSetting("bookonline_name")
            certificationUser = widget.getCertification(passwd)
            if certificationUser[0] > 18:
                return False
            certificationCorrect = widget.recupCertif(numId, typMedia)
            if not certificationCorrect:
                if __addon__.getSetting("actifnewpaste")  != "false":
                    if typMedia == "movie":
                        sql = "SELECT certif FROM filmsPub WHERE numId={}".format(numId)
                    else:
                        sql = "SELECT certif FROM seriesPub WHERE numId={}".format(numId)
                    certificationMedia = createbdhk.extractMedias(sql=sql, unique=1)
                elif __addon__.getSetting("actifhk") != "false":
                    if typMedia == "movie":
                        sql = "SELECT certification FROM movieCertification WHERE numId={}".format(numId)
                    else:
                        sql = "SELECT certification FROM tvshowCertification WHERE numId={}".format(numId)
                    certificationMedia = extractMedias(sql=sql, unique=1)
            else:
                certificationMedia = [certificationCorrect]
            if certificationMedia and  isinstance(certificationMedia[0], int):

                if certificationMedia[0] > certificationUser[0]:
                    showInfoNotification("tu es trop jeune .....")
                    return True
            else:
                if certificationUser[1] == 0:
                    if typMedia == "movie":
                        if __addon__.getSetting("actifnewpaste")  != "false":
                            sql2 = "SELECT numId FROM filmsRepos WHERE famille='concert'"
                            concerts = createbdhk.extractMedias(sql=sql2)
                            concerts = [x[0] for x in concerts]
                            if int(numId) in concerts:
                                return False
                        elif __addon__.getSetting("actifhk") != "false":
                            sql2 = "SELECT numId FROM movieFamille WHERE famille='#Concerts'"
                            concerts = extractMedias(sql=sql2)
                            concerts = [x[0] for x in concerts]
                            if int(numId) in concerts:
                                return False
                        if certificationUser[0] > 11:
                            if __addon__.getSetting("actifnewpaste")  != "false":
                                sql2 = "SELECT numId FROM filmsRepos WHERE famille='concert' or famille='spectacle' or famille='docu'"
                                autres = createbdhk.extractMedias(sql=sql2)
                                autres = [x[0] for x in autres]
                                if int(numId) in autres:
                                    return False
                            elif __addon__.getSetting("actifhk") != "false":
                                sql2 = "SELECT numId FROM movieFamille WHERE famille='#Sports' or famille='#Spectacles'"
                                autres = extractMedias(sql=sql2)
                                autres = [x[0] for x in autres]
                                if int(numId) in autres:
                                    return False
                    showInfoNotification("tu es trop jeune .....")
                    return True

            return False
        except:
            return False

def getVerifLinksSerie(paramstring, numId, saison, episode):
    cr = Crypt()
    sql = "SELECT link, release, taille FROM episodes WHERE link IN ('{}')".format("','".join(paramstring))
    #notice(sql)
    liste = createbdhk.extractMedias(sql=sql)
    paramstring = []
    for l in liste:
        l = list(l)
        if "Go" in l[2]:
            l[2] = int(float(l[2].replace("Go", "")) * 1000000000)
        elif "Mo" in l[2]:
            l[2] = int(float(l[2].replace("Mo", "")) * 100000000)
        else:
            l[2] = int(float(l[2]))
        paramstring.append(l)
    linksDarkino = [x for x in paramstring if len(x[0]) == 12]
    links = [x for x in paramstring if x not in linksDarkino]
    dictLiensfichier = cr.extractLinks([x[0] for x in links])
    #notice(dictLiensfichier)
    links2 = [x for x in links if dictLiensfichier[x[0]]]
    if links2 or not KEYALLDEB:
        links = links2
    if linksDarkino:
        linkOk, linkOut = cr.validLinkDark([x[0] for x in linksDarkino])
        linksDarkino = [x for x in linksDarkino if x[0] not in linkOut]
    links += linksDarkino
    #notice(links)

    #torrents
    if __addon__.getSetting("torrentvalid") != "false" and KEYALLDEB:

        # torrent db
        #linksTorrent  = [(cr.cryptFile(x[0], 0), x[1], x[2]) for x in paramstring if len(x[0]) == 40]
        #if linksTorrent:
        #    linksTorrent = verifLinksTorrent(linksTorrent)
        #try:
        if KEYALLDEB:
            keyApi = __addon__.getSetting("apikeytorrent")
            site = __addon__.getSetting("sitetorrent")

            req = requests.get("https://{}/stream/serie/{}:{}:{}.json?api_key={}&keyall={}".format(site, numId, saison, episode, keyApi, KEYALLDEB))
            #notice(req.json())
            linkTorrent2 = req.json()
            linksTorrent = []
            for l in linkTorrent2["streams"]:
                hsh = l["url"].split("/")[-1].split("-")[0]
                reso = groups = re.findall(r"[A-Za-z0-9]+(?:-[A-Za-z0-9]+)?", l["title"].split("\n")[-1])
                reso = '.'.join(reso)
                if len(hsh) == 40:
                    linksTorrent.append((hsh, reso,  float(re.search(r"\d+(?:\.\d+)?", l['name'].split("|")[1]).group()) * 1024**3))
            #notice(linksTorrent)
        #except:
        #    linksTorrent = []
    else:
        linksTorrent = []
    links += linksTorrent

    #notice(links)
    return sorted(links, key=lambda x: x[2], reverse=True)

def getParams(paramstring, u2p=0, saisonIn=1, suite=0, torrent=0, episode=0):
    result = {}
    paramstring = paramstring.split("*")
    #notice(paramstring)

    # ===================================================================== resos ===========================================================
    resos, timing = getresos()
    histoReso = None
    addon = 0


    #cr = cryptage.Crypt()
    #dictResos = cr.extractReso([(x.split("#")[0].split("@")[0], x.split("#")[0].split("@")[1]) for x in paramstring])
    #dictResos = {x.split("#")[0].split("@")[1]: dictResos[x.split("#")[0].split("@")[1]] if dictResos[x.split("#")[0].split("@")[1]] else x.split("#")[1] for x in paramstring}
    typMedia = xbmc.getInfoLabel('ListItem.DBTYPE')
    if not typMedia:
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        xbmc.sleep(500)
        typMedia = xbmc.getInfoLabel('ListItem.DBTYPE')
    #notice("type media " + typMedia)
    #notice(xbmc.getInfoLabel('ListItem.DBID'))
    #notice(xbmc.getInfoLabel('ListItem.DBTYPE'))
    #numId = xbmc.getInfoLabel('ListItem.DBID')

    if typMedia != "movie":
        if not torrent:
            links = getVerifLinksSerie(paramstring, u2p, saisonIn, episode)
        else:
            links = paramstring
        #notice("links")
        #notice(links)
        paramstring = links
        title = xbmc.getInfoLabel('ListItem.TVShowTitle')
        saison = xbmc.getInfoLabel('ListItem.Season')
        #notice("title " + xbmc.getInfoLabel('Player.Title'))
        if xbmc.Player().isPlaying():
            infoTag = xbmc.Player().getVideoInfoTag()
            title = infoTag.getTVShowTitle()
            saison = infoTag.getSeason()
        #notice("serie" + title)
        histoReso = None
        if title:
            idDB = xbmc.getInfoLabel('ListItem.DBID')
            histoReso = gestionBD("get", title, saison)
            #notice("histo %s" %histoReso)
        else:
            liste = gestionBD("last")
            if liste:
                idDB, title, saison, reso = liste
                histoReso = (reso, )

    pos = 0
    if suite:
        if histoReso and histoReso[0]:
            resos = [histoReso[0]] + resos
            timing = 2
    if u2p:
        timing = 0
        numId = u2p

    try:
        for reso in resos:
            #notice(reso)
            for i, lien in enumerate(paramstring):
                if reso in lien[1]:
                    pos = i
                    raise StopIteration
    except StopIteration: pass

    # ========================================================================================================================================

    selected = 0
    if len(paramstring) == 1:
        if type(paramstring[0]) == str:
            result['url'] = paramstring[0]
        else:
            result['url'] = paramstring[0][0]

    else:
        dialog = xbmcgui.Dialog()
        #if u2p and numId != "divers":
        #    tabNomLien = ["Bande Annonce"]
        #else:
        #    tabNomLien = []

        """
        tabNomLien = []
        paramstring = orderLiens(dictResos, paramstring)
        #notice(paramstring)
        try:
            tabNomLien += ["#%d (%s - %.2fGo)" %(i + 1, dictResos[x.split("#")[0].split("@")[1]][0], (int(dictResos[x.split("#")[0].split("@")[1]][1]) / 1000000000.0)) for i, x in enumerate(paramstring)]
        except:
            tabNomLien += ["#%d (ind)" %(i + 1) for i, x in enumerate(paramstring)]
        """
        #notice(paramstring)
        #paramstringTorrent = [x for x in paramstring if len(x[0]) == 40]
        #paramstringDDL = [x for x in paramstring if x not in paramstringTorrent]
        tabNomLien = []
        for i, x in enumerate(paramstring):
            #notice(x)
            if len(x[0]) == 40:
                #notice("hash")
                tabNomLien.append("[COLOR %s]#%d[/COLOR]| %s - %.2fGo-T" %(colorLiens(x[1]), i + 1, x[1], (int(x[2]) / 1000000000.0)))
            elif len(x[0]) != 12:
                #notice("1fichier")
                tabNomLien.append("[COLOR %s]#%d[/COLOR]| %s - %.2fGo-1F" %(colorLiens(x[1]), i + 1, x[1], (int(x[2]) / 1000000000.0)))

        addons = {}
        addons["tmdb_id"] = u2p
        if typMedia != "movie":
            addons["typ"] = "tv"
        getaddon = False
        #=========================== wastream ================================
        notice(["type media", typMedia])
        if __addon__.getSetting("wastream") != "false" and typMedia != "movie":
            getaddon = True
            addons["wastream"] = {"cls": "WaStream", "url": __addon__.getSetting("urlwa"), "saison": saisonIn, "episode": episode}
            #notice(["wastream", numId])
            #link = resolve_wastream(numId)
            #result["url"] = link
            #saisonIn, episode
            tabNomLien.append("[COLOR red]#WaStream[/COLOR]")

        #=========================== streamfusion ================================
        notice(["type media", typMedia])
        if __addon__.getSetting("streamfusion") != "false" and typMedia != "movie":
            getaddon = True
            addons["streamfusion"] = {"cls": "StreamFusion", "url": __addon__.getSetting("urlsf"), "saison": saisonIn, "episode": episode}
            #notice(["wastream", numId])
            #link = resolve_wastream(numId)
            #result["url"] = link
            tabNomLien.append("[COLOR red]#StreamFusion[/COLOR]")

        #=========================== streamfusion ================================
        notice(["type media", typMedia])
        if __addon__.getSetting("comet") != "false" and typMedia != "movie":
            getaddon = True
            addons["comet"] = {"cls": "Comet", "url": __addon__.getSetting("urlcom"), "saison": saisonIn, "episode": episode}
            #notice(["wastream", numId])
            #link = resolve_wastream(numId)
            #result["url"] = link
            tabNomLien.append("[COLOR red]#Comet[/COLOR]")

        if getaddon:
            LinksMultiAddons(addons)


        #tabNomLien = ["[COLOR %s]#%d[/COLOR]| %s - %.2fGo-1F" %(colorLiens(x[1]), i + 1, x[1], (int(x[2]) / 1000000000.0)) if len(x[0]) != 12 else\
        #      "[COLOR %s]#%d[/COLOR]| %s - %.2fGo-D" %(colorLiens(x[1]), i + 1, x[1], (int(x[2]) / 10000000000.0)) for i, x in enumerate(paramstringDDL)]
        #tabNomLien += ["[COLOR %s]#%d[/COLOR]| %s - %.2fGo-T" %(colorLiens(x[1]), i + 1, x[1], (int(x[2]) / 1000000000.0)) if len(x[0]) != 12 else\
        #     "[COLOR %s]#%d[/COLOR]| %s - %.2fGo-D" %(colorLiens(x[1]), i + 1, x[1], (int(x[2]) / 10000000000.0)) for i, x in enumerate(paramstringTorrent)]

        #if u2p and numId != "divers":
        #    tabNomLien += ["Casting", "Similaires", "Recommendations"]
        selected = dialog.select("Choix lien Reso", tabNomLien, int(timing) * 1000, pos)
        if selected != -1:
            #notice(selected)
            if u2p  and numId != "divers":
                if "Bande Annonce" == tabNomLien[selected]:
                    mdb = TMDB(__keyTMDB__)
                    tabBa = mdb.getNumIdBA(numId, typMedia)
                    if tabBa:
                        selectedBa = dialog.select("Choix B.A", ["%s (%s)" %(x[0], x[1]) for x in tabBa], 0, 0)
                        if selectedBa  != -1:
                            keyBa = tabBa[selectedBa][2]
                            xbmc.executebuiltin("RunPlugin(plugin://plugin.video.youtube/?action=play_video&videoid={})".format(keyBa), True)

                    return
                elif tabNomLien[selected] in ["Similaires", "Recommendations"]:
                    loadSimReco(numId, typMedia, tabNomLien[selected])
                    return
                elif tabNomLien[selected] in ["[COLOR red]#WaStream[/COLOR]"]:
                    #notice("liens watream")
                    addon = 1
                    result['url'] = resolve_wastream(u2p,"tv", saisonIn, episode)
                    reso = "watream"
                elif tabNomLien[selected] in ["[COLOR red]#StreamFusion[/COLOR]"]:
                    #notice("liens watream")
                    addon = 1
                    result['url'] = resolve_torrent("streamfusion", u2p,"tv", saisonIn, episode)
                    reso = "streamfusion"
                elif tabNomLien[selected] in ["[COLOR red]#Comet[/COLOR]"]:
                    #notice("liens watream")
                    addon = 1
                    result['url'] = resolve_torrent("comet", u2p,"tv", saisonIn, episode)
                    reso = "comet"




                else:
                    result['url'] = paramstring[selected][0]
                    reso = paramstring[selected][1]
            else:
                result['url'] = paramstring[selected][0]
                reso = paramstring[selected][1]
        else:
            return

    if typMedia != "movie":
        if u2p:
            gestionBD("update", u2p, title, saisonIn, reso, pos)
        else:
            if title:
                gestionBD("update", idDB, title, saison, reso, pos)
    #notice(["url", result["url"]])
    if not torrent and len(result["url"]) != 40:
        # debridage
        if not addon:
            ApikeyAlldeb = getkeyAlldebrid()
            ApikeyRealdeb = getkeyRealdebrid()
            #ApikeyUpto = getkeyUpto()
            Apikey1fichier = getkey1fichier()
            validKey = False
            cr = Crypt()

            if len(result['url'].strip()) == 12:
                urlLink = cr.urlBase + cr.cryptFile(result['url'].strip(), 0)
            else:
                urlLink = cr.url + "/?" + cr.cryptFile(result['url'], 0)
            result['url'] = urlLink

            if ApikeyAlldeb:
                erreurs = ["AUTH_MISSING_AGENT", "AUTH_BAD_AGENT", "AUTH_MISSING_APIKEY", "AUTH_BAD_APIKEY"]
                urlDedrid, status = cr.resolveLink(result['url'], ApikeyAlldeb)
                if status in erreurs:
                    validKey = False
                    showInfoNotification("Key Alldebrid Out!")
                    #addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
                    #addon.setSetting(id="keyalldebrid", value="")
                else:
                    result['url'] = urlDedrid.strip()
                    validKey = True

            if ApikeyRealdeb and not validKey:
                urlDedrid, status = cr.resolveLink(result['url'], ApikeyRealdeb)
                if status == "err":
                    showInfoNotification("Key Realdebrid Out!")
                    #addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
                    #addon.setSetting(id="keyrealdebrid", value="")
                else:
                    result['url'] = urlDedrid.strip()
                    validKey = True

            if Apikey1fichier and not validKey:

                urlDedrid, status = cr.resolveLink(result['url'], Apikey1fichier)
                result['url'] = urlDedrid.strip()
                #if status == 16:
                #    showInfoNotification("Key Uptobox Out!")
                    #addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
                    #addon.setSetting(id="keyupto", value="")

        if result['url'][:-4] in [".mkv", ".mp4"]:
            title = unquote(result['url'][:-4].split("/")[-1])#, encoding='latin-1', errors='replace')
        else:
            title = unquote(result['url'].split("/")[-1])#, encoding='latin-1', errors='replace')
        try:
            title = unicode(title, "utf8", "replace")
        except: pass
        result["title"] = title
    else:
        result['title'] = "Saison {} Episode {}".format(saisonIn, episode)

    #notice(result)
    return result

def gestionThumbnails():
    nbT = __addon__.getSetting("thumbnails")
    try:
        nbT = int(nbT)
    except:
        nbT = 0
    if nbT > 0:
        dbTexture = xbmcvfs.translatePath("special://home/userdata/Database/Textures13.db")
        repThumb = xbmcvfs.translatePath("special://thumbnails")
        cnx2 = sqlite3.connect(dbTexture)
        cur2 = cnx2.cursor()
        tabFiles = []
        for dirpath, dirs, files in os.walk(repThumb):
            for filename in files:
                fname = os.path.normpath(os.path.join(dirpath,filename))
                tabFiles.append(fname)
        if len(tabFiles) > 7000:
            tabFiles.sort(key=os.path.getmtime, reverse=True)
            for f in tabFiles[7000:]:
                head ,tail = os.path.split(f)
                cur2.execute("SELECT id FROM texture WHERE cachedurl LIKE '{}'".format("%" + tail + "%"))
                num = cur2.fetchone()
                if num:
                    cur2.execute("DELETE FROM texture WHERE id=?", (num[0],))
                    cur2.execute("DELETE FROM sizes WHERE idtexture=?", (num[0],))
                xbmcvfs.delete(f)
        cnx2.commit()
        cur2.close()
        cnx2.close()

def prepareUpNext(title, numId, saison, episode):
    #notice(episode)
    if __addon__.getSetting("actifnewpaste")  != "false":
        link = uptobox.getLinkUpNext(numId, saison, int(episode) + 1)
    elif __addon__.getSetting("actifhk") != "false":
        sql = "SELECT link FROM tvshowEpisodes \
                WHERE numId={} AND saison='Saison {}' AND episode=='S{}E{}'".format(numId, str(saison).zfill(2), str(saison).zfill(2), str(int(episode) + 1).zfill(2))
        link = extractMedias(sql=sql, unique=1)
    #notice(link)
    next_info = {}
    if link:
        try:
            mdb = TMDB(__keyTMDB__)
            tabEpisodes = mdb.saison(numId, saison)
            #['Épisode 1', 'Maud Bachelet semble vivre une vie parfaite ', '2022-01-10', '/jkV6JVxXIiDujhEyFreyEo5IxUe.jpg', 0.0, 1, 1]
            if [x for x in tabEpisodes if x[-1] > int(episode)]:
                next_info["current_episode"] = [dict([
                    ("episodeid", x[-1]),
                    ("tvshowid", 0),
                    ("title", x[0]),
                    ("art", {
                        'thumb': "http://image.tmdb.org/t/p/w500%s" %x[3],
                        'tvshow.clearart': "",
                        'tvshow.clearlogo': "",
                        'tvshow.fanart': "",
                        'tvshow.landscape': "http://image.tmdb.org/t/p/w500%s" %x[3],
                        'tvshow.poster': '',
                    }),
                    ("season", x[-2]),
                    ("episode", x[-1]),
                    ("showtitle", title),
                    ("plot", x[1]),
                    ("rating", x[-3]), ("firstaired", x[2])]) for x in tabEpisodes if x[-1] == int(episode)][0]
                next_info["next_episode"] = [dict([
                    ("episodeid", x[-1]),
                    ("tvshowid", 0),
                    ("title", x[0]),
                    ("art", {
                        'thumb': "http://image.tmdb.org/t/p/w500%s" %x[3],
                        'tvshow.clearart': "",
                        'tvshow.clearlogo': "",
                        'tvshow.fanart': "",
                        'tvshow.landscape': "http://image.tmdb.org/t/p/w500%s" %x[3],
                        'tvshow.poster': '',
                    }),
                    ("season", x[-2]),
                    ("episode", x[-1]),
                    ("showtitle", title),
                    ("plot", x[1]),
                    ("rating", x[-3]), ("firstaired", x[2])]) for x in tabEpisodes if x[-1] == int(episode) + 1][0]
                #plugin://plugin.video.sendtokodiU2P/?action=playHK&lien=7UM9cgSAc%40yqh47Hp6a6kW%23&u2p=154454

                param = {"u2p": numId, 'action': "playHKEpisode", 'lien': link[0],  "title": title, 'episode': int(episode) + 1, "saison": saison, "typMedia": "episode"}
                urls = link[0].split("#")
                url = sys.argv[0] + '?' + urlencode(param)
                next_info["play_url"] = url
                #next_info["notification_time"] = 70
            #notice(next_info)
            if next_info["next_episode"]:
                notice(upnext_signal("plugin.video.sendtokodiU2P", next_info))
        except: pass

def playEpisode(params):
    #notice(params)
    histoReso = gestionBD("getHK", params["u2p"], params["saison"])
    if histoReso:
        resoP = histoReso[0]
    #notice(resoP)
    tabreso = ["1080", "720", "2160", "480", "4K", '360']

    reso = "1080"
    for motif in tabreso:
        ch = r'(\.)(%s)p?\.' %motif
        r = re.search(ch, resoP, re.I)
        if r:
            reso = motif
    if xbmc.Player().isPlaying():
        tt = 0
        for x in range(3):
            tt = xbmc.Player().getTotalTime()
            if tt:
                break
            time.sleep(0.1)
        t = xbmc.Player().getTime()
        if __addon__.getSetting("bookonline") != "false":
            numEpisode = int(params["episode"]) - 1
            widget.pushSite("http://%s/requete.php?name=%s&type=posserie&numid=%s&pos=%.3f&tt=%.3f&saison=%s&episode=%s"\
                 %(__addon__.getSetting("bookonline_site"), __addon__.getSetting("bookonline_name"), params["u2p"], t, tt, params["saison"], str(numEpisode)))
        else:
            widget.bdHK(numId=params["u2p"], pos=t, tt=tt, typM="episode", saison=int(params["saison"]), episode=int(params["episode"]) - 1)
    sql = "SELECT link, release FROM episodes WHERE numId={} AND saison={} AND episode={}".format(int(params["u2p"]), int(params["saison"]), int(params["episode"]))
    liste = createbdhk.extractMedias(sql=sql)
    params["lien"] = liste[0][0]
    for link, release in liste:
        if reso in release:
            params["lien"] = link
            break
    param = {"u2p": params["u2p"], 'action': "playHK", 'lien': params["lien"], 'episode': params["episode"], "saison": params["saison"], "typMedia": "episode"}
    #param = ["%s=%s" %(k, v) for k, v in param.items()]
    #param = "&".join(param)
    #notice(param)
    #xbmc.executebuiltin("RunPlugin(plugin://plugin.video.sendtokodiU2P/?%s)" %param)
    playMediaHK(param)

"""
def im(cookie, tokens, vcodetype, codeString, vcode_path):
        self.cookie = cookie
        self.tokens = tokens
        self.vcodetype = vcodetype
        self.codeString = codeString
        self.vcode_path = vcode_path

        # windowItems
        self.image = xbmcgui.ControlImage(80, 100, 500, 200, self.vcode_path)
        self.buttonInput = xbmcgui.ControlButton(
            100, 330, 220, 50, label=u'ok, alignment=6, font='font13', textColor='0xFFFFFFFF'
        )
        self.buttonRefresh = xbmcgui.ControlButton(
            290, 330, 220, 50, label=u'annuler', alignment=6, font='font13', textColor='0xFFFFFFFF'
        )
        self.addControls([self.image, self.buttonInput, self.buttonRefresh])
        self.buttonInput.controlRight(self.buttonRefresh)
        self.buttonRefresh.controlLeft(self.buttonInput)
        self.setFocus(self.buttonInput)
"""

def debridTorrent(hsh, u2p, typM = "tvshow"):
    tabLinks = []
    if KEYALLDEB:
        debrid = 'alldeb'
        tabLinks = []
        deb = AllDebridClient(KEYALLDEB, "")
        rep = deb.upload_magnets([hsh])
        magnet_id = rep["data"]["magnets"][0]["id"]
        rep = deb.magnet_status(magnet_id)
        rep2  = rep.get("data", None)
        if rep2:
            for f in rep["data"]["magnets"]["files"]:
                if  "e" in list(f.keys()):
                    for ff in f['e']:
                        if  "e" in list(ff.keys()):
                            for fff in ff['e']:
                                if fff.get("s", 0) > 1000000:
                                    tabLinks.append((fff['n'], fff['s'], fff['l']))
                        else:
                            if ff.get("s", 0) > 1000000:
                                tabLinks.append((ff['n'], ff['s'], ff['l']))
                else:
                    if f.get("s", 0) > 1000000:
                        tabLinks.append((f['n'], f['s'], f['l']))

    #notice(tabLinks)
    if tabLinks:
        if typM == "tvshow":
            try:
                if __addon__.getSetting("bookonline") != "false":
                    vus = widget.responseSite("http://%s/requete.php?name=%s&type=getvu" %(__addon__.getSetting("bookonline_site"), __addon__.getSetting("bookonline_name")))
                else:
                    vus =  widget.getVu("tvshow")
            except:
                vus = []
            vus = [x for x in vus if x.split("-")[0] == u2p]
            #notice(vus)
            #['62286-8-7']
        else:
            vus = []
        #col = verifVu(vus, x[0], params["u2p"])
        col = "white"
        tabNomLien = [("[COLOR %s]#[/COLOR]%s - %0.2fGo" % (col, x[0], x[1] / 1000000000.0), x[2]) for x in tabLinks if x[0][-4:].upper() not in (".NFO", ".ZIP", ".RAR", ".JPG")]
        #notice(tabNomLien)
        if len(tabLinks) == 1:
            lien = tabLinks[0][2]
        else:
            dialog = xbmcgui.Dialog()
            selected = dialog.select("Choix lien Torrent", sorted([x[0] for x in tabNomLien]), 0, 0)
            if selected != -1:
                lien = tabNomLien[selected][1]
        if debrid == "alldeb":

            err, url = deb.unlock(lien)
            deb.delete_magnet([magnet_id])
        if url:
            release = unquote(url.split("/")[-1])
            #renam = RenameMedia()
            #title, saison, episode, year = renam.extractInfo(release, typM="tvshow")
            notice([url, release])
            return url, release[:-4]
        else:
            return "", ""


def resolve_torrent(addon, numId, typM="movie", saison="", episode=""):
    #notice("resolve streamfusion")

    keyTMDB = __addon__.getSetting("apikey")
    urlc = "https://api.themoviedb.org/3/{}/{}/external_ids?api_key={}".format(typM, numId, keyTMDB)
    data = requests.get(urlc).json()
    imdb = data.get("imdb_id")

    filename = f"{imdb}.json"
    with io.open(os.path.join(xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/addons'), filename), "r", encoding="utf-8") as f:
        data = json.load(f)
    links = data[addon]


    deb = AllDebridClient(KEYALLDEB, "")
    tabLinks = [(k, v) for k, v in links.items()]
    url = ""
    if len(tabLinks) == 1:
        hsh = tabLinks[0][1][0]
        tabLinks, magnet_id = deb.getLinksHash(hsh, saison, episode)
        if tabLinks:
            ok, url = deb.unlock(tabLinks[0])
            deb.delete_magnet([magnet_id])
    else:
        dialog = xbmcgui.Dialog()
        selected = dialog.select("Choix lien %s" %addon, sorted([x[0] for x in tabLinks]), 0, 0)
        if selected != -1:
            for hsh in tabLinks[selected][1]:
                tabLinks, magnet_id = deb.getLinksHash(hsh, saison, episode)
                #notice([tabLinks, magnet_id])
                if tabLinks:
                    ok, url = deb.unlock(tabLinks[0])
                    deb.delete_magnet([magnet_id])
                    if ok:
                        break
    #notice(url)
    return url


def resolve_wastream(numId, typM="movie", saison="", episode=""):
    keyTMDB = __addon__.getSetting("apikey")
    if typM == "movie":
        urlc = "https://api.themoviedb.org/3/movie/{}/external_ids?api_key={}".format(numId, keyTMDB)
    else:
        urlc = "https://api.themoviedb.org/3/tv/{}/external_ids?api_key={}".format(numId, keyTMDB)
    data = requests.get(urlc).json()
    imdb = data.get("imdb_id")
    #url = __addon__.getSetting("urlwa")
    #wa = WaStream(url)
    #if typM == "movie":
    #    links = wa.getMovie(imdb)
    #else:
    #    links = wa.getSerie(imdb, saison, episode)

    filename = f"{imdb}.json"
    with io.open(os.path.join(xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/addons'), filename), "r", encoding="utf-8") as f:
        data = json.load(f)
    links = data["wastream"]

    deb = AllDebridClient(KEYALLDEB, "")
    tabLinks = [(k, v) for k, v in links.items()]
    url = ""
    if len(tabLinks) == 1:
        lien = tabLinks[0][1][0]
        ok, url = deb.unlock(lien)
    else:
        dialog = xbmcgui.Dialog()
        selected = dialog.select("Choix lien WaStream", sorted([x[0] for x in tabLinks]), 0, 0)
        if selected != -1:
            for lien in tabLinks[selected][1]:
                ok, url = deb.unlock(lien)
                if ok:
                    break
    #notice(url)
    return url

def playMediaHK(params):
    #xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.Open", "params": { "item": {"file":"' + tmp_file + '"} }, "id": 1}')

    typMedia = xbmc.getInfoLabel('ListItem.DBTYPE')
    if not typMedia:
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        xbmc.sleep(500)
        typMedia = xbmc.getInfoLabel('ListItem.DBTYPE')
    #notice(typMedia)
    numId = params["u2p"]
    try:
        typMedia = params["typMedia"]
    except: pass
    if "torrent" in params.keys():
        torrent = 1
    else:
        torrent = 0

    #======================================== certification ========================================
    if testCertification(numId, typMedia):
        return
    #======================================  fin certif ============================================
    if typMedia not in ["movie", "audioBook"]:
        if "saison" in params.keys():
            try:
                title = params['title']
            except:
                title = ""
            numEpisode = params['episode']
            saison = params["saison"]
            li = xbmcgui.ListItem()
            media = MediaSp(**{"title": title, "episode": numEpisode, "season": saison, "numId": numId, "typMedia": typMedia})
            updateInfoTagVideo2(li, media)
            #xbmcgui.ListItem().setInfo('video', {"title": title, "episode": numEpisode, "season": saison})
        else:
            title = xbmc.getInfoLabel('ListItem.TVShowTitle')
            saison = xbmc.getInfoLabel('ListItem.Season')
            numEpisode = xbmc.getInfoLabel('ListItem.Episode')
            if not numEpisode and 'episode' in params.keys():
                numEpisode = params['episode']
        #prepareUpNext(title, numId, saison, numEpisode)
    else:
        saison = 1
        numEpisode = 0

    result = getParams(params['lien'], u2p=numId, saisonIn=saison, torrent=torrent, episode=numEpisode)
    if result and "url" in result.keys():
        result["url"] = result["url"].replace(" ", "%20")
        if typMedia not in ["movie", "audioBook"]:
            result["episode"] = numEpisode
            result["season"] = saison
        else:
            result["episode"] = ""
            result["season"] = ""
        url = str(result['url'])

        #showInfoNotification("playing title " + result['title'])
        #try:
        result['title'] = xbmc.getInfoLabel('ListItem.TITLE')
        #notice(["url", url])
        if len(url) == 40:
                #notice("play torrent")
                """
                param = {"action": "playTorrent", "u2p": params["u2p"], 'lien': url, 'delF': 'ko', "typM": "tvshow"}
                from urllib.parse import urlencode

                param = urlencode(param)

                # Ferme tous les dialogs modaux
                xbmc.executebuiltin("Dialog.Close(all,true)")


                xbmc.sleep(300)

                #param = "&".join(param)
                #notice(param)
                #torrent.playTorrent(param)
                url_plugin = "plugin://plugin.video.sendtokodiU2P/?%s" % param
                xbmc.executebuiltin(
                    'ActivateWindow(Videos,"%s",return)' % url_plugin
                )
                """
                try:
                    url , title = debridTorrent(url, numId)
                except Exception as e:
                    notice(e)
                    url , title = "", ""
                result['title'] = title
                result["url"] = url

        #=========================== Addons Stremio ================================
        #notice(typMedia)
        if params['lien'] == "wastream":
            notice(["wastream", numId])
            link = resolve_wastream(numId)
            result["url"] = link

        if params['lien'] == "streamfusion":
            notice(["streafusion", numId])
            link = resolve_torrent("streamfusion", numId)
            result["url"] = link

        if params['lien'] == "comet":
            notice(["comet", numId])
            link = resolve_torrent("comet", numId)
            result["url"] = link



        #notice(result)
        showInfoNotification("playing title " + result['title'])
        listIt = createListItemFromVideo(result)
        #notice(listIt)
        if "skin" in params.keys():
            if not torrent:
                li = mepInfos(params["u2p"])
            else:
                li = listIt
            if torrent:
                pass
            else:

                xbmc.Player().play(url, li)
        else:
            listIt.setProperty('IsPlayable', "true")

        if __addon__.getSetting("autoplay") != "false" and typMedia == "movie":
            xbmc.Player().play(url, listIt)
        else:
            xbmcplugin.setResolvedUrl(__handle__, True, listitem=listIt)
        #except Exception as e:
        #    notice("playMediaHK - Erreur Play " + str(e))
        threading.Thread(target=gestionThumbnails).start()
        count = 0
        time.sleep(2)
        while not xbmc.Player().isPlaying():
            count = count + 1
            if count >= 20:
                return
            else:
                time.sleep(1)
        try:
            trk = actifTrakt()
        except:
            trk = None
        if numId != "divers" and str(numId) != "0":
            if typMedia == "movie":
                if __addon__.getSetting("bookonline") != "false":
                    #notice("http://%s/requete.php?name=%s&type=getpos&numid=%s&media=%s" %(__addon__.getSetting("bookonline_site"), __addon__.getSetting("bookonline_name"), params["u2p"], typMedia))
                    recupPos = widget.responseSite("http://%s/requete.php?name=%s&type=getpos&numid=%s&media=%s" %(__addon__.getSetting("bookonline_site"), __addon__.getSetting("bookonline_name"), params["u2p"], typMedia))
                    if recupPos:
                        seek = float(recupPos[0])
                    else:
                        seek = 0
                else:
                    seek = widget.bdHK(sauve=0, numId=int(numId))
            elif typMedia == "audioBook":
                seek = 0
            else:
                if __addon__.getSetting("bookonline") != "false":
                    recupPos = widget.responseSite("http://%s/requete.php?name=%s&type=getpos&numid=%s&media=%s&saison=%s&episode=%s" \
                        %(__addon__.getSetting("bookonline_site"), __addon__.getSetting("bookonline_name"), params["u2p"], typMedia, saison, numEpisode))
                    if recupPos:
                        seek = float(recupPos[0])
                    else:
                        seek = 0
                else:
                    seek = widget.bdHK(sauve=0, numId=int(numId), typM=typMedia, saison=saison, episode=numEpisode)
        else:
            seek = 0
        if seek > 0:
            dialog = xbmcgui.Dialog()
            resume = dialog.yesno('Play Video', 'Resume last position?')
            #notice(seek)
            if resume:
                notice(xbmc.getInfoLabel('Player.Title'))
                xbmc.Player().seekTime(int(seek))
            else:
                notice("delete")
        okUpNext = True
        tt = xbmc.Player().getTotalTime()
        #web_pdb.set_trace()
        #notice("typeMedia " + typMedia)

        # scrobble
        try:
            if trk and numId != "divers" and str(numId) != "0":
                pos = 0.0
                if typMedia == "movie":
                    r = trk.scrobble(title="", year=0, numId=numId, pos=pos, typM="movie", mode="start")
                else:
                    r = trk.scrobble(title="", year=0, numId=numId, pos=pos, season=saison, number=numEpisode, typM="show", mode="start")
        except: pass
        t = 0
        while xbmc.Player().isPlaying():
            t = xbmc.Player().getTime()
            #notice(t)
            if tt == 0:
                tt = xbmc.Player().getTotalTime()
            time.sleep(1)
            if t > 10 and okUpNext and typMedia not in ["movie", "audioBook"]:
                try:
                    prepareUpNext(title, numId, saison, numEpisode)
                    okUpNext = False
                except: pass
        if t > 180 and numId != "divers" and str(numId) != "0":
            if typMedia == "movie":
                if __addon__.getSetting("bookonline") != "false":
                    widget.pushSite("http://%s/requete.php?name=%s&type=posmovie&numid=%s&pos=%.3f&tt=%.3f" %(__addon__.getSetting("bookonline_site"), __addon__.getSetting("bookonline_name"), params["u2p"], t, tt))
                else:
                    widget.bdHK(numId=numId, pos=t, tt=tt, typM=typMedia)
            elif typMedia == "episode":
                if __addon__.getSetting("bookonline") != "false":
                    requete = "http://%s/requete.php?name=%s&type=posserie&numid=%s&pos=%d&tt=%d&saison=%s&episode=%s"\
                         %(__addon__.getSetting("bookonline_site"), __addon__.getSetting("bookonline_name"), params["u2p"], t, tt, saison, numEpisode)
                    widget.pushSite(requete)
                    if tt and (float(t) / float(tt) * 100.0) > 90.0:
                        #push on "on continue"
                        widget.gestOC(params["u2p"], "ajout")
                        scraperUPTO.extractEpisodesOnContinue()
                        #
                        p = {"name": __addon__.getSetting("bookonline_name"), "type": "vuepisodes", "numid": params["u2p"], "saison": saison, "episodes": numEpisode,"vu": "1"}
                        requete = "http://%s/requete.php" %__addon__.getSetting("bookonline_site") + '?' + urlencode(p)
                        widget.pushSite(requete)
                else:
                    widget.bdHK(numId=numId, pos=t, tt=tt, typM=typMedia, saison=saison, episode=numEpisode)

        #fin scrooble
        try:
            if trk and numId != "divers" and str(numId) != "0" and t :
                try:
                    pos = t / tt * 100.0
                except:
                    pos = 10.0
                if typMedia == "movie":
                    trk.scrobble(title="", year=0, numId=numId, pos=pos, typM="movie", mode="stop")
                else:
                    trk.scrobble(title="", year=0, numId=numId, pos=pos, season=saison, number=numEpisode, typM="show", mode="stop")
        except: pass

        nettHistoDB(__database__)

        if os.path.isfile(xbmcvfs.translatePath('special://home/addons/plugin.video.sendtokodiU2P/rskin.txt')) and __addon__.getSetting("rskin"):
            time.sleep(5)
            xbmc.executebuiltin('ReloadSkin')
            time.sleep(0.05)
            os.remove(xbmcvfs.translatePath('special://home/addons/plugin.video.sendtokodiU2P/rskin.txt'))

    return