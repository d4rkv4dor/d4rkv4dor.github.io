#!/usr/bin/python
# -*- coding:Utf-8 -*-
import requests
import ast
import re
import random, sys
import io
import time
import sqlite3
import os
import json
try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser
try:
    # Python 3
    from urllib.parse import unquote, urlencode
    unichr = chr
except ImportError:
    # Python 2
    from urllib import unquote, urlencode
import urllib.request
try:
    from util import *
    EXTUPTO = ADDON.getSetting("extupto")
except:
    EXTUPTO = "uptobox.eu"


class Crypt:

    def __init__(self):
        self.s = "chmo.:ABCDEGIKLMNOPRSTUWYbpstux"
        #self.s = 'azertyupqsdfghjkmwxcvbn23456789AZERTYUPQSDFGHJKMWXCVBN'
        self.tabKey = ['Wq97wQmdlPOJBGvNnbxcDHzFj2gkYURftEKV163A5MeSp0r8IXoZTyiuCLh4as', 'KdSiCM8nf9tIbwDzH04X325O67mRuBFNWkQvVTEcpexGy1agZYqAPLsUolJjrh', '9Y6kURti4gzhCIGwZM0PpBXuoVcl3e5Ky7fNFSTjms8AbHErxWDO2dnLaJQvq1',
    'AfEeszp0ZRgJuqtyGOokvFjhHPrVb4cB2NIXnU6KxaS8dlQ57TLCi39wMWY1Dm', 'yBhlVjFDA1EKYuoGZ2NqnxUesdMS3Ofp0arzwtRIc8kb9JPQ4WH5Tvg6iCX7mL', 'wTfLtya01MnzeYSW9d4FoHcNkJZCvXQ3bgiGpEu825RrjP7OVKUxDqAIlsBh6m',
    'ButrYenv6fX9NmCUI3Rs2V7hTAWHDkKglLc50jFQOpSPqy8w1EiZ4abJGodMzx', '2gcSr0w8YeiXM4sAd6uxthnbqJ9BpQO7ZzKG3HTFUIVjlkEvL1oWRNmDyC5afP', 'R3ExPNnUhDyujmK4LAMVd52vIZtplqiHragzoekJ1TSb9W6GcOYfFBC0X87Qsw',
    'ZgtAmxakYKD0zpcsqLT9wHndP5B4Ir2huCRFQfb8M67UlVN3eGyvOEjWSJoiX1', 'YZt86WeN3ECKHA1x9vdhF4jzISL2RGurgpPsDwlJ7n0mOaBoyMUVcfib5TkXqQ', 'uhl8iYHO6poTIvgDQ904PayfcrZ1J5zkmREFLVqBsUdNMxj7XCnGwtbW3AeKS2',
    'VaU8utB2lSwpNq0yHhF7RMTJncDbIZYXs9dAiCzmj613QxOEW4PgfGL5oKvrek', 'zOFWr7JetVh0yN6vslDxn24fwHukXmEUj5qCSTRbgiYQPIZAM1aGL9dB8oKc3p', 'kM1AUuqnNfrKWRj0tOzm7C9lYShZGcQBL5J4DyF3wXT2aEd8VvoPHpbiexgsI6',
    '9HYjEcLTutQpI0rO3M75ZvwA4GFK2koqzhUiCny6xNSdmRfJegDaVBXbs1PW8l', '0UScdanhjeNVLrFXpx3wOD7ikZ4PBsmzJM8QI5RoyqWAtfEvY1l926TuHKCgGb', 'Bb3cNFeDkW5fwvVJm2QzgPiUL9nTZE4apdMSIqHhlxYrjC0AoK81uXRsOtGy76',
    'n4tmQckyLRd13vPebl9EzhBa0MKXGj7NUf26CH8r5AFYWOopuxSDZwsiVIqJgT', 'ceQ68PDBs4huny23trq7ClvFWiAKHzZ1bgURwo9pXIOxdLNYVSkEfa0GJ5jmMT', 'jxMyhCUpStFgzs81lBvrXEOHAK6PbwiRDNd4ZTJ2oI03Lk9mucaY5V7WnQefGq',
    'j4vcoE9lfpNwTsiDRQCdUbYu5k28JBWH7SeZrqyh3L6PxKGAXVOnm1tFIMazg0', 'Xk4teWwfzEBR9bHuUZoJ3Y0NxQO8phmGT1aFiyncj7KLqvPIrAlDsSC256dgVM', 'mWKyZVEilfpHD752LJRGvQuqIe0MawOnP81BFz69khdCSUsXjc4NYg3xrtboTA',
    '8LzXWwKhl2oGdTYAM6yIaJ3bBce4fsg9rUuQktCxpi7VD0OZPnvFNSEHqmRj15', 'kopQbKsUMz4FCn0aqwyNAc23DlET7GWSfmd1IHO8PtevxrV6ZLghjYRXBJu5i9', 'rz5wTkpAKgYH32OuRl4nD0yNQva186FM7eJiScBIXhbVsdUE9oGqxPCtjLmWfZ',
    'H5KQUnLCvgWSYOka3PFAjhJ0cw61z2yR8tqmMXIlsupeZfoVNxT74EirdbDBG9', 'zvlEitNwd0bPqasYDArjgnJKIOoCSp589mM2TFy6WZk1RuxGBQL3hX7cHfeVU4', 'd5hjmCsA34nZu9pV76Sbz1NRYO8iFGlTLcMqUxHBgKvofXawDytIkeEWQPrJ02']
        self.tab0 = 'wTfLtya01MnzeYSW9d4FoHcNkJZCvXQ3bgiGpEu825RrjP7OVKUxDqAIlsBh6m'
        self.tab1 = "zvlEitNwd0bPqasYDArjgnJKIOoCSp589mM2TFy6WZk1RuxGBQL3hX7cHfeVU4"
        self.numRot = 0
        self.posTable = 0
        self.adrPbi = "http://pastebin.com/raw/"
        self.adrPbi = "https://anotepad.com/note/read/"
        self.motifAnotepad = r'.*<\s*div\s*class\s*=\s*"\s*plaintext\s*"\s*>(?P<txAnote>.+?)</div>.*'

    def loadFile(self, numPaste):
        html_parser = HTMLParser()
        num = self._decryptNumPaste(numPaste)
        posDecal = self._numDecal(num)
        #posDecal = 39
        #print(num, posDecal)
        try:
            rec = requests.get(self.adrPbi + num, timeout=5)
            r = re.match(self.motifAnotepad, rec.text, re.MULTILINE|re.DOTALL)
        except:
            r = ""
        try:
            tx = r.group("txAnote")
            tx = html_parser.unescape(tx)
            lignes = self._decrypt(tx, posDecal)
        except:
            lignes = []
        return lignes

    def _revBit(self, n):
        low = n & 0xf
        high = n >> 4
        return (low * 16 + high) ^ 0xff

    def _numDecal(self, num):
        v1 = sum([ord(x) for x in num])
        v1 = self._revBit(v1) % 70
        return v1

    def cryptNumPaste(self, cr):
        rot = random.randint(1, 15)
        tx = self.tabKey[rot - 1]
        txCrypt = ""
        v = 0
        for i, t in enumerate(cr):
            pos = (tx.index(t) + ((i + 1) * rot)) % len(tx)
            v += ord(tx[pos])
            txCrypt += tx[pos]
        v = self._revBit(v & 0xff)
        v &= 0xf
        v ^= rot
        txCrypt += str(hex(v))[2:]
        return txCrypt

    def _decryptNumPaste(self, tx2):
        try:
            v = int("0x%s" %tx2[8:], 16)
            tx2 = tx2[:8]
            v1 = sum([ord(x) for x in tx2]) & 0xff
            v1 = self._revBit(v1)
            v1 &= 0xf
            rot = v ^ v1
            tx = self.tabKey[rot - 1]
            txdec = ""
            for i, t in enumerate(tx2):
                pos = (tx.index(t) - ((i + 1) * rot)) % len(tx)
                txdec += tx[pos]
        except:
            txdec = ""
        return txdec

    def _cryptDecrypt(self, tx, decal, crypt=1):
        if crypt == 0:
            decal *= -1
        tab = sorted(list(set([x for x in tx])))
        cr = [(tab[(tab.index(t) + decal) % len(tab)]) for t in tx]
        return "".join(cr)


    def _decrypt(self, tx, posDecal):
        lignes = [x for x in tx.splitlines() if x]
        tabDecrypt = []
        try:
            for j, ligne in enumerate(lignes):
                if j == 0:
                    ligne = list(ligne)
                    decal = self.s.index(ligne.pop(posDecal))
                    ligne = "".join(ligne)
                    tabDecrypt.append(self._cryptDecrypt(ligne, decal, crypt=0))
                else:
                    ligne = self._cryptDecrypt(ligne, decal, crypt=0)
                    tabDecrypt.append(ligne)
        except:
            tabDecrypt = ["erreur decrypt"]
        return tabDecrypt

    def extractReso(self, tabLinkCrypte):
        tabLinkDecrypt = []
        for t in tabLinkCrypte:
            numPaste, link = t
            num = self._decryptNumPaste(numPaste)
            v1 = sum([ord(x) for x in num]) % len(self.tabKey)
            pos1 = ord(num[0]) % len(self.tabKey[0])
            pos2 = ord(num[1]) % len(self.tabKey[0])
            pos3 = ord(num[2]) % len(self.tabKey[0])
            posRefl = ord(num[3]) % len(self.tabKey[0])
            rot1 = self._swapKey(self.tabKey[v1 % len(self.tabKey)], pos1)
            rot2 = self._swapKey(self.tabKey[(v1 + 1) % len(self.tabKey)], pos2)
            rot3 = self._swapKey(self.tabKey[(v1 + 2) % len(self.tabKey)], pos3)
            rotRefl = self._swapKey(self.tabKey[(v1 + 3) % len(self.tabKey)], posRefl)
            tabRot = [rot1, rot2, rot3]
            reflecteur = {x: rotRefl[-(i + 1)] for i, x in enumerate(rotRefl)}
            link = self._decryptLink(tabRot, reflecteur, link)
            tabLinkDecrypt.append(link)
        tabResos, tabSizes, tabRelease = self.searchReso(tabLinkDecrypt)
        dictResos = {x[1]: (tabResos[i], tabSizes[i], tabRelease[i]) for i, x in enumerate(tabLinkCrypte)}
        return dictResos

    def searchReso(self, tabFilesCode):
        tabResos = []
        tabSizes = []
        tabRelease = []
        filesInfo = self.fileInfo(tabFilesCode)
        for f in filesInfo:

            try:
                tabSizes.append(f["file_size"])
                tabRelease.append(f["file_name"])
                argv = self.extractResoName(f["file_name"])
                ext = argv.pop(-2)
                if not argv[4]:
                    if "avi" in ext:
                        argv[4] = ['480']
                resoRelease = "%s" %".".join(["-".join(x) for x in argv[1:] if x])
                tabResos.append(resoRelease)

            except Exception as e:
                tabResos.append("ind")
                tabSizes.append("0")
                tabRelease.append("")
                #print("Erreur search reso", f["file_code"], e)
        return tabResos, tabSizes, tabRelease

    def extractResoNameOld(self, name):
        reso = {"1080": False, "720": False, "2160": False, "480": False, "4K": False, '360': False, "3D": False, "xvid":False}
        typeReso = {"HDlight": False, "Light": False, "ultraHDlight": False, "fullhd": False, "REMUX": False, "4KLight": False}
        source = {"BLURAY": False, "WEB": False, "WEBRIP": False, "DVDRiP": False, "BDRIP": False, "HDTV": False, "BRRip": False, "HDrip": False, "Cam": False}
        audio = {"VO": False, "VOSTFR": False, "VFF": False, "VFI": False, 'VFQ': False, "VF": False, "FR.JP": False, "FR.EN": False, "VOA": False, "TRUEFRENCH": False, "French": False, "Multi": False}
        extension = {"avi": False, "divx": False, "mkv": False, "mp4": False, "ts": False, "mpg": False}
        name = unquote(name)
        #print(name)
        for m in ["_", " ", "[", "]", "-", "(", ")"]:
            name = name.replace(m, ".")
        masque = r'(.*)([\.\(]19\d\d|[\.\(]20\d\d)(?P<release>[\.\)].*)'
        r = re.match(masque, name)
        try:
            release = r.group("release")
        except:
            release = name
            #print("erreur reso name:", name)
        for tab in [reso, typeReso, audio, source]:
            for motif in tab.keys():
                ch = r'(\.)(%s)p?\.' %motif
                print(ch)
                r = re.search(ch, release, re.I)
                if r:
                    tab[motif] = True
        for ext in extension.keys():
            if ext == release[-3:]:
                extension[ext] = True

        return [name, [k for k, v in reso.items() if v], [k for k, v in typeReso.items() if v], [k for k, v in audio.items() if v], [k for k, v in extension.items() if v], [k for k, v in source.items() if v]]


    def extractResoName(self, name):
        reso = {"2160": False, "4K": False, "1080": False, "720": False, "480": False, "360": False, "3D": False, "XVID": False}
        typeReso = {"ULTRAHDLIGHT": False, "4KLIGHT": False, "FULLHD": False, "HDLIGHT": False, "LIGHT": False, "REMUX": False}
        source = {"BLURAY": False, "WEBRIP": False, "WEB": False, "BDRIP": False, "BRRIP": False, "DVDRIP": False, "HDTV": False, "HDRIP": False, "CAM": False}
        audio = {"VOSTFR": False, "TRUEFRENCH": False, "FRENCH": False, "VF": False, "VFF": False, "VFI": False, "VFQ": False, "VO": False, "MULTI": False}
        extension = {"avi": False, "divx": False, "mkv": False, "mp4": False, "ts": False, "mpg": False}

        name = unquote(name)

        # Normalisation scène
        clean = re.sub(r'[\s_\-\[\]\(\)]+', '.', name.upper())

        # Extraction après l'année (si possible)
        m = re.search(r'(19\d{2}|20\d{2})(?P<release>.*)', clean)
        release = m.group("release") if m else clean

        # Regex audio (FRENCH sans SUBFRENCH)
        audio_regex = {
            "VOSTFR": r'(?:\.|^)(VOST(FR)?)(?:\.|$)',
            "TRUEFRENCH": r'(?:\.|^)(TRUEFRENCH)(?:\.|$)',
            "FRENCH": r'(?<!SUB)(?<!SUB\.)(?<!SUB-)(?<!SUB_)(?:\.|^)(FRENCH)(?:\.|$)',
            "VF": r'(?:\.|^)(VF|VFF|VFI|VFQ)(?:\.|$)',
            "VO": r'(?:\.|^)(VO)(?:\.|$)',
            "MULTI": r'(?:\.|^)(MULTI)(?:\.|$)',
        }

        for key, rgx in audio_regex.items():
            if re.search(rgx, release, re.I):
                audio[key] = True

        # Détection reso / source / type
        for table in (reso, typeReso, source):
            for key in table:
                if re.search(rf'(?:\.|^){key}P?(?:\.|$)', release, re.I):
                    table[key] = True

        # Extension
        ext = name.lower().split('.')[-1]
        if ext in extension:
            extension[ext] = True

        return [
            name,
            [k for k, v in reso.items() if v],
            [k for k, v in typeReso.items() if v],
            [k for k, v in audio.items() if v],
            [k for k, v in extension.items() if v],
            [k for k, v in source.items() if v],
        ]

    def cryptFolder(self, tx, crypt=1):
        decal = int(tx[-1])
        tx = tx[:-1]
        if crypt == 0:
            decal *= -1
        tab = sorted(list(set([x for x in tx])))
        cr = [(tab[(tab.index(t) + decal) % len(tab)]) for t in tx]
        return "".join(cr) + str(abs(decal))

    def fldP(self, num, link):
        num = self.cryptFolder(num, crypt=0)
        v1 = sum([ord(x) for x in num]) % len(self.tabKey)
        pos1 = ord(num[0]) % len(self.tabKey[0])
        pos2 = ord(num[1]) % len(self.tabKey[0])
        pos3 = ord(num[2]) % len(self.tabKey[0])
        posRefl = ord(num[3]) % len(self.tabKey[0])
        rot1 = self._swapKey(self.tabKey[v1 % len(self.tabKey)], pos1)
        rot2 = self._swapKey(self.tabKey[(v1 + 1) % len(self.tabKey)], pos2)
        rot3 = self._swapKey(self.tabKey[(v1 + 2) % len(self.tabKey)], pos3)
        rotRefl = self._swapKey(self.tabKey[(v1 + 3) % len(self.tabKey)], posRefl)
        tabRot = [rot1, rot2, rot3]
        reflecteur = {x: rotRefl[-(i + 1)] for i, x in enumerate(rotRefl)}
        link = self._decryptLink(tabRot, reflecteur, link)
        return link

    def resolveLink(self, numPaste, link, key="", keyAllD="", keyRD="", addCompte=0, cr=0):
        if len(numPaste) == 8:
            num = numPaste
        else:
            num = self._decryptNumPaste(numPaste)
        #notice(link)
        v1 = sum([ord(x) for x in num]) % len(self.tabKey)
        pos1 = ord(num[0]) % len(self.tabKey[0])
        pos2 = ord(num[1]) % len(self.tabKey[0])
        pos3 = ord(num[2]) % len(self.tabKey[0])
        posRefl = ord(num[3]) % len(self.tabKey[0])
        rot1 = self._swapKey(self.tabKey[v1 % len(self.tabKey)], pos1)
        rot2 = self._swapKey(self.tabKey[(v1 + 1) % len(self.tabKey)], pos2)
        rot3 = self._swapKey(self.tabKey[(v1 + 2) % len(self.tabKey)], pos3)
        rotRefl = self._swapKey(self.tabKey[(v1 + 3) % len(self.tabKey)], posRefl)
        tabRot = [rot1, rot2, rot3]
        reflecteur = {x: rotRefl[-(i + 1)] for i, x in enumerate(rotRefl)}
        link = self._decryptLink(tabRot, reflecteur, link)
        #notice(link)
        if addCompte == 1 and key:
            link = self._addCompte(key, link)
        elif addCompte == 2 and key:
            link = self._uploadRemote(key, "https://%s/%s" %(EXTUPTO, link))
        elif key:
            link = self._linkDownloadUptobox(key, link)
        elif keyAllD:
            link = self._linkDownloadAlldebrid(keyAllD, "https://%s/%s" %(EXTUPTO, link))
        elif keyRD:
            link = self._linkDownloadRealdebrid(keyRD, "https://%s/%s" %(EXTUPTO, link))
        elif cr == 0:
            link = ("http://mauvaisFormat/test.mkv", "err")
        return link

    def _uploadRemote(self, key, media):
        """ upload sur le compte depuis lien http"""
        urlUpload = self._linkUpload(key, t="remote")
        payload_dict = {'urls': json.dumps([media]) }
        r = requests.post(urlUpload , data=payload_dict)
        data = [x for x in r.text.split("\n") if "uptobox" in x]
        try:
            data = json.loads(data[0])
        except:
            r = requests.post(urlUpload , data=payload_dict)
            data = [x for x in r.text.split("\n") if "uptobox" in x]
            data = json.loads(data[0])
        fileCode = data["url"].split("/")[-1]
        deleteFile = data["deleteUrl"]
        return fileCode, deleteFile

    def _linkUpload(self, key, t="local"):
        """creation lien pour uploader fichier"""
        url = "https://%s/api/upload?token=%s" %(EXTUPTO, key)
        r = requests.get(url, timeout=2.0)
        data = r.json()
        urlUpload = "https:%s" %data["data"]["uploadLink"]
        if t != "local":
            urlUpload = urlUpload.replace("/upload", "/remote")
        urlUpload = urlUpload.replace("uptobox.com", EXTUPTO)
        return urlUpload

    def _addCompte(self, key, filecode):
        url1 = 'https://%s/api/user/file/alias?token=' %EXTUPTO + key + '&file_code=' + filecode
        r3 = requests.get(url1)

        data = json.loads(r3.text)
        return data["data"]["file_code"], ""

    def _decryptLink(self, tabRot, reflecteur, link):
        self.numRot = 0
        self.posTable = 0
        fichCr = ""
        alpha = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
        for lCr in link:
            for rot in tabRot[::-1]:
                lCr = rot[alpha.index(lCr)]
            lCr = reflecteur[lCr]
            for rot in tabRot:
               lCr = alpha[rot.index(lCr)]
            fichCr += lCr
            tabRot[self.numRot] = self._swapKey(tabRot[self.numRot], 1)
        return fichCr

    def _swapKey(self, key, swap):
        self.posTable += 1
        self.posTable %= len(key)
        if self.posTable == 0:
            self.numRot += 1
            self.numRot %= 3
        key = "".join([key[(i + swap) % len(key)]  for i in range(len(key))])
        return key

    def _linkDownloadUptobox(self, key, fileCode):
        url1 = "https://%s/api/link?token=%s&file_code=%s" % (EXTUPTO, key, fileCode)
        try:
            req = requests.get(url1)
            dict_liens = req.json()
            dlLink = dict_liens["data"]["dlLink"]
            status = dict_liens["statusCode"]
        except Exception as e:
            #print(e)
            dlLink = ""
            status = "err"

        dlLink = dlLink.replace("uptobox.com", EXTUPTO)
        return dlLink, status

    def _linkDownloadAlldebrid(self, key, lien):
        dlLink = ""
        statut = "ok"
        url1 = "http://api.alldebrid.com/v4/link/unlock?agent=u2p&apikey=%s&link=%s" % (key.strip() , lien)
        req = requests.get(url1)
        dict_liens = req.json()
        try:
            if dict_liens["status"] == "success":
                dlLink = dict_liens['data']['link']
            else:
                statut = dict_liens["error"]["code"]
        except: pass
        return dlLink, statut

    def _linkDownloadRealdebrid(self, key, lien):
        headers = {'Authorization': 'Bearer %s' %key}
        data = {'link': lien, 'password':''}
        r = requests.post('https://api.real-debrid.com/rest/1.0/unrestrict/link', data=data, headers=headers)
        dictData = r.json()
        if 'error' in dictData.keys():
            link, status = "", 'err'
        else:
            link, status = dictData['download'], "ok"

        return link, status

    def decryptR(self, tx, tab0, tab1):
        texCrypt = ""
        for j, t in enumerate(tx):
            tab0 = self._swapKeyR(tab0, j)
            d = {x: tab0[i] for i, x in enumerate(tab1)}
            texCrypt += d[t]
        return texCrypt

    def _swapKeyR(self, key, swap):
        key = "".join([key[(i + swap) % len(key)]  for i in range(len(key))])
        return key

    def idRentry(self, lePaste):
        """extraction id paste d'un rentry"""
        urlCode = self.decryptR(lePaste, self.tab0, self.tab1)
        x = requests.get('https://rentry.org/{}/raw'.format(urlCode)).content
        return [x.decode()]

    def updateBD(self, chemin, key="", typkey="upto", typeDown=1, numRentry="PbFWq", forceDownload=0):
      #print(chemin)
      cnx = sqlite3.connect("%s/resources/serie.db" % chemin)
      cur = cnx.cursor()
      cur.execute("""CREATE TABLE IF NOT EXISTS bd(
                      `id`    INTEGER PRIMARY KEY,
                      link TEXT,
                      UNIQUE (link))
                        """)
      cnx.commit()
      try:
        cur.execute("SELECT link FROM bd")
        tabLinkBD = [x[0] for x in cur.fetchall() if x]
      except:
        tabLinkBD = []
      linkBD = self.idRentry(numRentry)
      for linkOrig in linkBD:
        if linkOrig:
            if linkOrig not in tabLinkBD or forceDownload:
                link = self.decryptR(linkOrig, self.tab0, self.tab1)
                if typkey == "upto":
                    url, err = self._linkDownloadUptobox(key, link.strip())
                elif typkey == "alldeb":
                    url, err = self._linkDownloadAlldebrid(key, "https://%s/%s" %(EXTUPTO, link.strip()))
                else:
                    url, err = self._linkDownloadRealdebrid(key, "https://%s/%s" %(EXTUPTO, link.strip()))
                if typeDown == 1:
                    resume_header = {'Range': 'bytes=%d-' % 0}
                    response = requests.get(url, headers=resume_header, stream=True,  verify=True, allow_redirects=True)
                    handle = open(os.path.join(chemin, "MyVideos119-U2P.zip"), "wb")
                    for chunk in response.iter_content(chunk_size=1024 * 30):
                        if chunk:  # filter out keep-alive new chunks
                            handle.write(chunk)
                else:
                    urllib.request.urlretrieve(url, os.path.join(chemin, "MyVideos119-U2P.zip"))
                cur.execute("REPLACE INTO bd (link) VALUES ('{}')".format(linkOrig))
                cnx.commit()
                tx = True
            else:
              tx = False
      cur.close()
      cnx.close()
      return tx

    def fileInfo(self, liste):
        #url1 = "http://uptobox.com/api/link/info?fileCodes=%s" %','.join(liste)
        url1 = "http://%s/api/link/info?fileCodes=%s" %(EXTUPTO, ','.join(liste))
        #print(url1)
        try:
            dict_liens = self.getDataJson(url1)
            dlLink = dict_liens["data"]["list"]
        except Exception as e:
            #print(dict_liens)
            notice("erreur fileinfo %s" %str(e))
            dlLink = []
        time.sleep(0.3)
        return dlLink

    def getDataJson(self, url, nbTest=1):
        """reconnection error json"""
        headers = {'Accept': 'application/json'}
        try:
            data = requests.get(url, headers=headers, timeout=5).json()
        except :
            time.sleep(0.5 * nbTest)
            notice("tentative reconnection : %.2fs" % (0.5 * nbTest))
            nbTest += 1
            if nbTest > 5:
                notice("error: url %s" %url)
                #with open("logExtract.txt", "a") as f:
                #    f.write("error: url => %s\n" %url)
                #sys.exit()
            return self.getDataJson(url, nbTest)
        else:
            return data

if __name__ == '__main__':

    #crypt

    cryptage = Crypt()
    cryptage.extractResoName("test.vf")
    sys.exit()
    a = time.time()
    cryptage.updateBD("C:/compile", key="175c78628290c32282175fac4cbc8abb3zxu4", typeDown=0)
    print(time.time() - a)
    a = time.time()
    cryptage.updateBD("C:/compile", key="175c78628290c32282175fac4cbc8abb3zxu4")
    print(time.time() - a)
